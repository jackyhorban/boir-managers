<?php
function boir_manager_activate(){
    global $wpdb;
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    $charset_collate = $wpdb->get_charset_collate();

    $clients_table = $wpdb->prefix . "boir_clients";
    $sql = "CREATE TABLE IF NOT EXISTS $clients_table (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        client_name VARCHAR(255) NOT NULL,
        client_email VARCHAR(255) NOT NULL,
        client_phone VARCHAR(20) NOT NULL,
        client_conversion_from TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES {$wpdb->users}(ID) ON DELETE CASCADE
    ) $charset_collate;";
    dbDelta($sql);

    $clients_fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $sql = "CREATE TABLE IF NOT EXISTS $clients_fillings_table (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        client_id BIGINT(20) UNSIGNED NOT NULL,
        filling_code VARCHAR(255),
        client_fincen_id TINYINT(1) DEFAULT 0,
        existing_reporting_company VARCHAR(255),
        filling_authorization TINYINT(1) DEFAULT 0,
        filling_status TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES {$clients_table}(id) ON DELETE CASCADE
    ) $charset_collate;";
    dbDelta($sql);

    $fillings_inital_data_table = $wpdb->prefix . "boir_fillings_inital_data";
    $sql = "CREATE TABLE IF NOT EXISTS $fillings_inital_data_table (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        client_id BIGINT(20) UNSIGNED NOT NULL,
        filling_id BIGINT(20) UNSIGNED NOT NULL,
        initial_legal_name TEXT,
        initial_alternate_name TEXT,
        initial_tax_type TEXT,
        initial_tax_number TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES {$clients_table}(id) ON DELETE CASCADE,
        FOREIGN KEY (filling_id) REFERENCES {$clients_fillings_table}(id) ON DELETE CASCADE
    ) $charset_collate;";
    dbDelta($sql);

    $fillings_jurisdiction_data_table = $wpdb->prefix . "boir_fillings_jurisdiction_data";
    $sql = "CREATE TABLE IF NOT EXISTS $fillings_jurisdiction_data_table (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        client_id BIGINT(20) UNSIGNED NOT NULL,
        filling_id BIGINT(20) UNSIGNED NOT NULL,
        juri_formation_country TEXT,
        juri_formation_state TEXT,
        juri_tribal TEXT,
        juri_other_tribe TEXT,
        juri_address_line_1 TEXT,
        juri_address_line_2 TEXT,
        juri_city TEXT,
        juri_state TEXT,
        juri_zip TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES {$clients_table}(id) ON DELETE CASCADE,
        FOREIGN KEY (filling_id) REFERENCES {$clients_fillings_table}(id) ON DELETE CASCADE
    ) $charset_collate;";
    dbDelta($sql);

    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";
    $sql = "CREATE TABLE IF NOT EXISTS $fillings_company_applicants_table (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        client_id BIGINT(20) UNSIGNED NOT NULL,
        filling_id BIGINT(20) UNSIGNED NOT NULL,
        applicant_last_name TEXT,
        applicant_first_name TEXT,
        applicant_middle_name TEXT,
        applicant_suffix TEXT,
        applicant_dob TEXT,
        applicant_address_type TEXT,
        applicant_address TEXT,
        applicant_city TEXT,
        applicant_country TEXT,
        applicant_state TEXT,
        applicant_zip TEXT,
        applicant_id_image TEXT,
        applicant_id_type TEXT,
        applicant_id_number TEXT,
        applicant_id_country TEXT,
        applicant_id_state TEXT,
        applicant_id_tribal_jurisdiction TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES {$clients_table}(id) ON DELETE CASCADE,
        FOREIGN KEY (filling_id) REFERENCES {$clients_fillings_table}(id) ON DELETE CASCADE
    ) $charset_collate;";
    dbDelta($sql);

    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";
    $sql = "CREATE TABLE IF NOT EXISTS $fillings_beneficial_owners_table (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        client_id BIGINT(20) UNSIGNED NOT NULL,
        filling_id BIGINT(20) UNSIGNED NOT NULL,
        owner_is_minor TINYINT(1) DEFAULT 0,
        owner_exemption TINYINT(1) DEFAULT 0,
        owner_last_name TEXT NOT NULL DEFAULT '',
        owner_first_name TEXT NOT NULL DEFAULT '',
        owner_middle_name TEXT NOT NULL DEFAULT '',
        owner_suffix TEXT NOT NULL DEFAULT '',
        owner_dob TEXT NOT NULL DEFAULT '',
        owner_address_type TEXT NOT NULL DEFAULT '',
        owner_address TEXT NOT NULL DEFAULT '',
        owner_city TEXT NOT NULL DEFAULT '',
        owner_country TEXT NOT NULL DEFAULT '',
        owner_state TEXT NOT NULL DEFAULT '',
        owner_zip TEXT,
        owner_id_image TEXT NOT NULL DEFAULT '',
        owner_id_type TEXT NOT NULL DEFAULT '',
        owner_id_number TEXT NOT NULL DEFAULT '',
        owner_id_country TEXT NOT NULL DEFAULT '',
        owner_id_state TEXT NOT NULL DEFAULT '',
        owner_id_tribal_jurisdiction TEXT NOT NULL DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES {$clients_table}(id) ON DELETE CASCADE,
        FOREIGN KEY (filling_id) REFERENCES {$clients_fillings_table}(id) ON DELETE CASCADE
    ) $charset_collate;";
    dbDelta($sql);

    $fillings_payments_table = $wpdb->prefix . "boir_fillings_payments";
    $sql = "CREATE TABLE IF NOT EXISTS $fillings_payments_table (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        client_id BIGINT(20) UNSIGNED NOT NULL,
        filling_id BIGINT(20) UNSIGNED NOT NULL,
        payment_type TEXT NOT NULL DEFAULT '',
		payment_card_holder TEXT NOT NULL DEFAULT '',
		transaction_id TEXT NOT NULL DEFAULT '',
        payment_amount TEXT NOT NULL DEFAULT '',
        payment_date TEXT NOT NULL DEFAULT '',
        payment_method TEXT NOT NULL DEFAULT '',
        card_number TEXT NOT NULL DEFAULT '',
        exp_date TEXT NOT NULL DEFAULT '',
        cvv TEXT NOT NULL DEFAULT '',
        card_country TEXT NOT NULL DEFAULT '',
        card_zip TEXT NOT NULL DEFAULT '',
        routing_number TEXT NOT NULL DEFAULT '',
        account_number TEXT NOT NULL DEFAULT '',
        payment_authorization TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES {$clients_table}(id) ON DELETE CASCADE,
        FOREIGN KEY (filling_id) REFERENCES {$clients_fillings_table}(id) ON DELETE CASCADE
    ) $charset_collate;";
    dbDelta($sql);

    $payments_columns = $wpdb->get_results("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_NAME = '{$fillings_payments_table}'");
    $payments_columns = array_column($payments_columns, 'COLUMN_NAME');

    $payments_columns_to_add = [
        'payment_card_holder' => "ADD payment_card_holder TEXT NOT NULL DEFAULT '' AFTER payment_type;",
        'transaction_id' => "ADD transaction_id TEXT NOT NULL DEFAULT '' AFTER payment_card_holder;",
        'card_zip' => "ADD card_zip TEXT NOT NULL DEFAULT '' AFTER card_country;",
        'user_agent' => "ADD user_agent TEXT NOT NULL DEFAULT '' AFTER card_zip;",
        'user_browser' => "ADD user_browser TEXT NOT NULL DEFAULT '' AFTER user_agent;",
        'user_ip' => "ADD user_ip TEXT NOT NULL DEFAULT '' AFTER user_browser;",
    ];

    foreach ($payments_columns_to_add as $column => $query) {
        if (!in_array($column, $payments_columns)) {
            $wpdb->query("ALTER TABLE $fillings_payments_table $query");
        }
    }

    $clients_columns = $wpdb->get_results("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_NAME = '{$clients_table}'");
    $clients_columns = array_column($clients_columns, 'COLUMN_NAME');

    if (!in_array('client_conversion_from', $clients_columns)) {
        $wpdb->query("ALTER TABLE $clients_table ADD client_conversion_from TEXT NOT NULL AFTER client_phone;");
    }

    $fillings_columns = $wpdb->get_results("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_NAME = '{$clients_fillings_table}'");
    $fillings_columns = array_column($fillings_columns, 'COLUMN_NAME');

    if (!in_array('filling_error_message', $fillings_columns)) {
        $wpdb->query("ALTER TABLE $clients_fillings_table ADD filling_error_message TEXT NOT NULL AFTER filling_status;");
    }

    if (!get_role('Customer')) {
        add_role('Customer', 'Customer', array(
            'read' => true,
            'edit_posts' => false,
            'delete_posts' => false,
        ));
    }






/*    $page_slug = "file";
    $page_title = "File Your BOIR Now";
    $page_content = "[boir_manager_form]";

    $existing_page = get_page_by_path($page_slug, OBJECT, 'page');

    if (!$existing_page) {
        $page_data = array(
            'post_title'    => $page_title,
            'post_name'     => $page_slug,
            'post_content'  => $page_content,
            'post_status'   => 'publish',
            'post_type'     => 'page'
        );
        wp_insert_post($page_data);
    }

    $page_slug = "signin";
    $page_title = "Sign In";
    $page_content = "[boir_manager_signin_form]";

    $existing_page = get_page_by_path($page_slug, OBJECT, 'page');

    if (!$existing_page) {
        $page_data = array(
            'post_title'    => $page_title,
            'post_name'     => $page_slug,
            'post_content'  => $page_content,
            'post_status'   => 'publish',
            'post_type'     => 'page'
        );
        wp_insert_post($page_data);
    }

    $page_slug = "dashboard";
    $page_title = "Dashboard";
    $page_content = "[boir_manager_dashboard]";

    $existing_page = get_page_by_path($page_slug, OBJECT, 'page');

    if (!$existing_page) {
        $page_data = array(
            'post_title'    => $page_title,
            'post_name'     => $page_slug,
            'post_content'  => $page_content,
            'post_status'   => 'publish',
            'post_type'     => 'page'
        );
        wp_insert_post($page_data);
    }*/




    
    $boir_manager_db_version = '1.0';
    $settings_table = $wpdb->prefix . 'boir_manager_settings';
	
    $charset_collate = $wpdb->get_charset_collate();
    
	// if ( $wpdb->get_var( "SHOW TABLES LIKE '{$settings_table}'" ) != $settings_table ) {
    // 	$sql = "CREATE TABLE $settings_table (
    // 	  id mediumint(9) NOT NULL AUTO_INCREMENT,
    // 	  flat_rate text NOT NULL,
    // 	  us_rates text NOT NULL,
    // 	  PRIMARY KEY  (id)
    // 	) $charset_collate;";
    
    // 	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    // 	dbDelta( $sql );
    // 	add_option( 'fintax_db_version', $fintax_db_version );
    	
    // 	$flat_rate = '0';
    // 	$us_rates = '["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"]';
    	
    // 	$wpdb->insert( 
    // 		$settings_table, 
    // 		array( 
    // 			'flat_rate' => $flat_rate,
    // 			'us_rates' => $us_rates,
    // 		) 
    // 	);
    // }
}


?>