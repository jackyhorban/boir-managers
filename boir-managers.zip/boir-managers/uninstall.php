<?php

if( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit();
global $wpdb;

// $settings_table = $wpdb->prefix . 'boir_manager_settings';

// $qry = "DROP TABLE IF EXISTS $settings_table;";
// $wpdb->query($qry);

delete_option("boir_manager_db_version");

function boir_manager_uninstall() {
    global $wpdb;
    require( plugin_dir_path( __FILE__ ) . 'deactivate.php');
    boir_manager_deactivate();

    // $tables = array(
    //     $wpdb->prefix . 'boir_fillings_payments',
    //     $wpdb->prefix . 'boir_fillings_beneficial_owners',
    //     $wpdb->prefix . 'boir_fillings_company_applicants',
    //     $wpdb->prefix . 'boir_fillings_jurisdiction_data',
    //     $wpdb->prefix . 'boir_fillings_inital_data',
    //     $wpdb->prefix . 'boir_clients_fillings',
    //     $wpdb->prefix . 'boir_clients'
    // );
    // foreach ($tables as $table) {
    //     $sql = "DROP TABLE IF EXISTS $table;";
    //     $wpdb->query($sql);
    // }
}

boir_manager_uninstall();

?>