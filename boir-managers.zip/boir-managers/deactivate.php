<?php

function boir_manager_deactivate() {
    $page_slugs = ["file", "signin", "dashboard"];
    foreach ($page_slugs as $page_slug) {
        $existing_page = get_page_by_path($page_slug);
        if ($existing_page) {
            wp_delete_post($existing_page->ID, true);
        }
    }

    if (get_role('Customer')) {
        remove_role('Customer');
    }

    dev_mode_scripts();
}

function dev_mode_scripts() {
    global $wpdb;

    // $table = $wpdb->prefix . "boir_fillings_beneficial_owners";
    // $sql = "DROP TABLE IF EXISTS $table;";
    // $wpdb->query($sql);
}

?>