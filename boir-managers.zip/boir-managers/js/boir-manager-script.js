var $ = jQuery;

$("#boirManagerForm").on("focus, click", "input, textarea, select, radio", function () {
    $(this).removeClass("error-border");
    if($(this).attr("type") == "radio"){
        $(this).parent().parent().removeClass("error-border");
    }

});


$("#applicant_last_name").on("change", function() {

    $("#add_applicant_error")
        .removeClass("hidden")
        .text("Unsaved Changes - Click \"Add Applicant\" to add this owner to the list.");
});

$("#owner_last_name").on("change", function() {
    $("#add_owner_error")
        .removeClass("hidden")
        .text("Unsaved Changes - Click \"Add Owner\" to add this owner to the list.");
});

$("input[name='existing_company[]']").on("change", function () {
    if($(this).is(":checked")){
        var existing_company = $(this).val();
        console.log(existing_company);
        if(existing_company == "yes"){
            $("#BOIRForm3").find(".company_applicants_form").removeClass("hidden");
            $("#BOIRForm3").find(".no_company_applicants_msg").addClass("hidden");
            $("#BOIRForm3").find(".data-card[data-id='1']").html("");
            if($("#BOIRForm3").find(".data-card[data-id='1']").length > 0){
                boirManagerGetApplicantsFun();
            }
        }else{
            $("#BOIRForm3").find(".company_applicants_form").addClass("hidden");
            $("#BOIRForm3").find(".no_company_applicants_msg").removeClass("hidden");
        }
    }
});

$(".has-or-divider-group1").find("input, select").on("keyup change", function () {
    hasDividerGroupFun($(this));
})
$(".has-or-divider-group2").find("input, select").on("keyup change", function () {
    hasDividerGroupFun($(this));
})
$(".has-or-divider-group3").find("input, select").on("keyup change", function () {
    hasDividerGroupFun($(this));
})

function hasDividerGroupFun(element){
    if ($(element).is("input")){
        $(element).parent().parent().find("select").removeClass("error-border");
        if($(element).val().length > 0){
            $(element).parent().parent().find("select").attr("disabled", true).val("").trigger("change");
        }else{
            $(element).parent().parent().find("select").attr("disabled", false);
        }
        return false;
    }else{
        $(element).parent().parent().find("input").removeClass("error-border");
        if($(element).val() != ""){
            $(element).parent().parent().find("input").attr("disabled", true).val("").trigger("change");
        }else{
            $(element).parent().parent().find("input").attr("disabled", false);
        }
        return false;
    }
}

$("#juri_formation_country").on("change", function () {
    juriFormationCountryTextFun($(this).val());
})

function juriFormationCountryTextFun(selectedVal){
    var text = $("#BOIRForm2").find("#juri_formation_country_type");
    if (text.length === 0) {
        return;
    }

    if (typeof selectedVal !== "string") {
        console.error("selectedVal is not a string");
        return;
    }

    var optionsArray = [
        "United States",
        "American Samoa",
        "Guam",
        "Marshal Islands",
        "Micronesia, Federated States",
        "Northern Mariana Islands",
        "Palau",
        "U.S. Virgin Islands"
    ];
    var foundInArray = false;
    $.each(optionsArray, function(index, value){
        if(value === selectedVal){
            foundInArray = true;
            $(text).text("Domestic");
        }
    });

    if(!foundInArray){
        $(text).text("Foreign");
    }
}

$("#boir_form1_submit").on("click", function (e) {
    e.preventDefault();
    $(this).attr("disabled", "disabled"); 
    $(this).parent().find(".loader").removeClass("hidden");
    $(this).parent().find(".error-message").addClass("hidden");
    boirManagerForm1Fun();
});

function boirManagerForm1Fun(){
    var container = $("#BOIRForm1");
    var header = $("#BOIRFormHeader1");

    var client_id = $("#boirManagerForm").find("#client_id").val();
    var filling_id = $("#boirManagerForm").find("#filling_id").val();

    var client_fincen_id = $(header).find("#request_fincen_id");
    var client_name = $(container).find("#name");
    var client_email = $(container).find("#email");
    var client_phone = $(container).find("#phone");
    var client_legal_name = $(container).find("#legal_name");
    var client_alternate_name = $(container).find("#alternate_name");
    var client_tax_type = $(container).find("#tax_type");
    var client_tax_number = $(container).find("#tax_number");
    var current_page_url = window.location.href;
	
    var client_alternate_name_val = $(client_alternate_name).val();
    var client_alternate_name_val_arr = client_alternate_name_val.split("\n");
    var client_alternate_name_val_arr_with_comma = client_alternate_name_val_arr.join(", ");
    client_alternate_name = client_alternate_name_val_arr_with_comma;
    
    var validate_status = validateData([client_name, client_email, client_legal_name, client_tax_type, client_tax_number]);
	

var client_number = $(client_tax_number).val(); 
if (!/^\d{9}$/.test(client_number)) {
        $(container).find(".error-message").removeClass("hidden").text("Tax Number must be 9 digits long and numeric. It cannot contain dashes or spaces.");
        $("#boir_form1_submit").removeAttr("disabled");
        $("#boir_form1_submit").parent().find(".loader").addClass("hidden");
        return false;
}

    if(!validate_status){
        $(container).find(".error-message").removeClass("hidden").text("Fill all required fields.");
        $("#boir_form1_submit").removeAttr("disabled");
        $("#boir_form1_submit").parent().find(".loader").addClass("hidden");
        return false;
    }



    var formData = new FormData();
    formData.append("action", "boir_form1");
    formData.append("client_id", client_id);
    formData.append("filling_id", filling_id);
    formData.append("client_fincen_id", $(client_fincen_id).is(':checked') ? 1 : 0);
    formData.append("client_name", $(client_name).val());
    formData.append("client_email", $(client_email).val());
    formData.append("client_phone", $(client_phone).val());
    formData.append("client_legal_name", $(client_legal_name).val());
    formData.append("client_alternate_name", client_alternate_name);
    formData.append("client_tax_type", $(client_tax_type).val());
    formData.append("client_tax_number", $(client_tax_number).val());
    formData.append("current_page_url", current_page_url);

    // var console_form_data_json = JSON.stringify(Object.fromEntries(formData));
    // console.log(console_form_data_json); 

    $.ajax({
        url: ajaxurl,
        type: "POST",
        processData: false,
        contentType: false,
        data: formData,
        success: function (response) {
            if (response.success) {
                boirManagerForm1SuccessFun(response, client_name);
                return true;
            } else {
                alert("Error: " + response.data);
                resetFormBtns(1);
                return false;
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
            resetFormBtns(1);
            return false;
        }
    });
}

function boirManagerForm1SuccessFun(response, client_name){
    var status = response.success;
    var user_id = response.data.user_id;
    var client_id = response.data.client_id;
    var filling_id = response.data.filling_id;
    var filling_code = response.data.filling_code;
    $("#boirManagerForm").find("#client_id").val(client_id);
    $("#boirManagerForm").find("#filling_id").val(filling_id);
    $("#boirManagerForm").find("#filling_code").val(filling_code);
    $("#boirManagerForm").find(".client-name-data").val(client_name);
    if(!status){
        $("#boir_form1_submit").removeAttr("disabled");
        $("#boir_form1_submit").parent().find(".loader").addClass("hidden");
    }else{
        $("#boir_form1_submit").removeAttr("disabled");
        $("#boir_form1_submit").parent().find(".loader").addClass("hidden");
        moveTabs(2);
        moveSteps(1);
    }
}

$("#boir_form2_submit").on("click", function (e) {
    e.preventDefault();
    $(this).attr("disabled", "disabled");
    $(this).parent().find(".loader").removeClass("hidden");
    $(this).parent().find(".error-message").addClass("hidden");
    boirManagerForm2Fun();
});

function boirManagerForm2Fun(){
    var container = $("#BOIRForm2");

    var client_id = $("#boirManagerForm").find("#client_id").val();
    var filling_id = $("#boirManagerForm").find("#filling_id").val();

    var juri_formation_country = $(container).find("#juri_formation_country");
    var juri_formation_state = $(container).find("#juri_formation_state");
    var juri_tribal = $(container).find("#juri_tribal");
    var juri_address_line_1 = $(container).find("#juri_address_line_1");
    var juri_address_line_2 = $(container).find("#juri_address_line_2");
    var juri_city = $(container).find("#juri_city");
    var juri_state = $(container).find("#juri_state");
    var juri_zip = $(container).find("#juri_zip");

    var validate_status = validateData([juri_formation_country, juri_address_line_1, juri_city, juri_state, juri_zip]);

    if(!validate_status){
        $(container).find(".error-message").removeClass("hidden").text("Fill all required fields.");
        $("#boir_form2_submit").removeAttr("disabled");
        $("#boir_form2_submit").parent().find(".loader").addClass("hidden");
        return false;
    }

    var juri_formation_state_data = false;
    if($(juri_formation_state).val() == ""){
        juri_formation_state_data = false;
        if($(juri_tribal).val() == ""){
            juri_formation_state_data = false;
        }else{
            juri_formation_state_data = true;
        }
    }else{
        juri_formation_state_data = true;
    }

    if(!juri_formation_state_data){
        $(juri_formation_state).addClass("error-border");
        $(juri_tribal).addClass("error-border");
        $(container).find(".error-message").removeClass("hidden").text("At least one is required from Formation: State or Tribal Jurisdiction.");
        $("#boir_form2_submit").removeAttr("disabled");
        $("#boir_form2_submit").parent().find(".loader").addClass("hidden");
        return false;
    }

    var formData = new FormData();
    formData.append("action", "boir_form2");
    formData.append("client_id", client_id);
    formData.append("filling_id", filling_id);
    formData.append("juri_formation_country", $(juri_formation_country).val());
    formData.append("juri_formation_state", $(juri_formation_state).val());
    formData.append("juri_tribal", $(juri_tribal).val());
    formData.append("juri_address_line_1", $(juri_address_line_1).val());
    formData.append("juri_address_line_2", $(juri_address_line_2).val());
    formData.append("juri_city", $(juri_city).val());
    formData.append("juri_state", $(juri_state).val());
    formData.append("juri_zip", $(juri_zip).val());

    $.ajax({
        url: ajaxurl,
        type: "POST",
        processData: false,
        contentType: false,
        data: formData,
        success: function (response) {
            if (response.success) {
                boirManagerForm2SuccessFun(response);
                return true;
            } else {
                alert("Error: " + response.data);
                resetFormBtns(2);
                return false;
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
            resetFormBtns(2);
            return false;
        }
    });
}

function boirManagerForm2SuccessFun(response){
    var status = response.success;
    if(!status){
        $("#boir_form2_submit").removeAttr("disabled");
        $("#boir_form2_submit").parent().find(".loader").addClass("hidden");
    }else{
        $("#boir_form2_submit").removeAttr("disabled");
        $("#boir_form2_submit").parent().find(".loader").addClass("hidden");
        moveSteps(2);
    }
}

$("#boir_form3_submit").on("click", function (e) {
    e.preventDefault();
    $(this).attr("disabled", "disabled"); 
    $(this).parent().find(".loader").removeClass("hidden");
    $(this).parent().find(".error-message").addClass("hidden");

    var existing_company = $("#BOIRForm3").find("input[name='existing_company[]']:checked").length > 0;

    if(!existing_company){
        resetFormBtns(3);
        $("#BOIRForm3").find(".error-message").removeClass("hidden").text("Please select at least one option.");
        $("#BOIRForm3").find(".field-radio").addClass("error-border");
        return false;
    }

    boirManagerForm3Fun();
});

function boirManagerForm3Fun(){
    var container = $("#BOIRForm3");

    var existing_company = $(container).find("input[name='existing_company[]']:checked");

    var formData = new FormData();
    formData.append("action", "boir_form3");
    formData.append("existing_company", $(existing_company).val());

    $.ajax({
        url: ajaxurl,
        type: "POST",
        processData: false,
        contentType: false,
        data: formData,
        success: function (response) {
            if (response.success) {
                boirManagerForm3SuccessFun(response);
                return true;
            } else {
                alert("Error: " + response.data);
                resetFormBtns(3);
                return false;
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
            resetFormBtns(3);
            return false;
        }
    });
}

function boirManagerForm3SuccessFun(response){
    var status = response.data.status;
    if(status=="false"){
        $("#boir_form3_submit").removeAttr("disabled");
        $("#boir_form3_submit").parent().find(".loader").addClass("hidden");
        $("#boir_form3_submit").parent().find(".error-message").removeClass("hidden").text("At least one company applicant is required.");
    }else{
        $("#boir_form3_submit").removeAttr("disabled");
        $("#boir_form3_submit").parent().find(".loader").addClass("hidden");
        moveSteps(3);
    }
}


$("#boir_form4_submit").on("click", function (e) {
    e.preventDefault();
    $(this).attr("disabled", "disabled");
    $(this).parent().find(".loader").removeClass("hidden");
    $(this).parent().find(".error-message").addClass("hidden");

    boirManagerForm4Fun();
});

function boirManagerForm4Fun(){
    var container = $("#BOIRForm4");

    var formData = new FormData();
    formData.append("action", "boir_form4");

    $.ajax({
        url: ajaxurl,
        type: "POST",
        processData: false,
        contentType: false,
        data: formData,
        success: function (response) {
            if (response.success) {
                boirManagerForm4SuccessFun(response);
                return true;
            } else {
                alert("Error: " + response.data);
                resetFormBtns(4);
                return false;
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
            resetFormBtns(4);
            return false;
        }
    });
}

function boirManagerForm4SuccessFun(response){
    var status = response.data.status;
    if(status=="false"){
        $("#boir_form4_submit").removeAttr("disabled");
        $("#boir_form4_submit").parent().find(".loader").addClass("hidden");
        $("#boir_form4_submit").parent().find(".error-message").removeClass("hidden").text("At least one beneficial owner is required.");
    }else{
        $("#boir_form4_submit").removeAttr("disabled");
        $("#boir_form4_submit").parent().find(".loader").addClass("hidden");
        moveSteps(4);
    }
}



$("#boir_form5_submit").on("click", function (e) {
    e.preventDefault();
    $(this).attr("disabled", "disabled");
    $(this).parent().find(".loader").removeClass("hidden");
    $(this).parent().find(".error-message").addClass("hidden");
    boirManagerForm5Fun();
});

function boirManagerForm5Fun(){
    var container = $("#BOIRForm5");

    var filling_authorization = $(container).find("#filling_authorization");
    if(!$(filling_authorization).is(":checked")){
        resetFormBtns(5);
        $("#BOIRForm5").find(".error-message").removeClass("hidden").text("Please certify that you have review your fillings and the information is correct.");
        return false;
    }

    var formData = new FormData();
    formData.append("action", "boir_form5");
    formData.append("filling_authorization", $(filling_authorization).is(":checked")?1:0);

    $.ajax({
        url: ajaxurl,
        type: "POST",
        processData: false,
        contentType: false,
        data: formData,
        success: function (response) {
            if (response.success) {
                boirManagerForm5SuccessFun(response);
                return true;
            } else {
                alert("Error: " + response.data);
                resetFormBtns(5);
                return false;
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
            resetFormBtns(5);
            return false;
        }
    });
}

function boirManagerForm5SuccessFun(response){
    var status = response.data.status;
    var payment_status = response.data.filling_payment_status;
    console.log(response);
    if(status=="false"){
        $("#boir_form5_submit").removeAttr("disabled");
        $("#boir_form5_submit").parent().find(".loader").addClass("hidden");
        $("#boir_form5_submit").parent().find(".error-message").removeClass("hidden").text("Please certify that you have review your fillings and the information is correct.");
    }else{
        $("#boir_form5_submit").removeAttr("disabled");
        $("#boir_form5_submit").parent().find(".loader").addClass("hidden");
        if(payment_status == "2"){
            const newUrl = "../dashboard?message=filling_updated";
            window.location.href = newUrl;
        }else{
            moveSteps(5);
            moveTabs(3);
        }
    }
}

$("#boir_form6_submit").on("click", function (e) {
    var checkout_processor = $('#boir_form_6_checkout_processor').val()
    console.log("checkout_processor",checkout_processor)
    if (checkout_processor === 'braintree') return;
    if (checkout_processor === 'gpay') return;
    e.preventDefault();
    $(this).attr("disabled", "disabled");
    $(this).parent().find(".loader").removeClass("hidden");
    $(this).parent().find(".error-message").addClass("hidden");
    boirManagerForm6Fun();
});


function boirManagerForm6Fun(){
    var container = $("#BOIRForm6");
    
    var checkout_processor = $(container).find("#boir_form_6_checkout_processor").val();
    var filling_id = $("#boirManagerForm").find("#filling_id").val();

    var card_holder = $(container).find("#payment_card_holder");
    var card_number = $(container).find("#payment_card_number");
    var exp_date = $(container).find("#payment_exp_date");
    var cvv = $(container).find("#payment_cvv");
    var card_country = $(container).find("#payment_card_country");
    var card_zip = $(container).find("#payment_card_zip");

    var routing_number = $(container).find("#routing_number");
    var account_number = $(container).find("#account_number");
    var confirm_account_number = $(container).find("#confirm_account_number");

    var payment_type = $(container).find("#boir_form6_submit").attr("data-payment-type");
    
    var validate_status = true;
    
    if(payment_type=="2" || payment_type=="3" || payment_type=="4" || payment_type=="5"){
        validate_status = validateData([routing_number, account_number, confirm_account_number]);
        if($(account_number).val()!=$(confirm_account_number).val()){
            resetFormBtns(6);
            $(container).find(".error-message").removeClass("hidden").text("Account numbers do not match.");
            return false;
        }
    }else{
        if (checkout_processor === 'nmi')
            validate_status = validateData([card_holder, card_number, exp_date, cvv, card_country, card_zip]);
    }

    if(!validate_status){
        resetFormBtns(6);
        $(container).find(".error-message").removeClass("hidden").text("Please fill out all required fields.");
        return false;
    }

    // var payment_type_2_authorization = $(container).find("#payment_type_2_authorization");
    // if(!$(payment_type_2_authorization).is(":checked") && payment_type!="1"){
    //     resetFormBtns(6);
    //     $(container).find(".error-message").removeClass("hidden").text("Please authorize payment by checking the top box.");
    //     return false;
    // }
    
    var client_name = $("#BOIRForm1").find("#name").val();
    var email = $("#BOIRForm1").find("#email").val();
    var business = $("#BOIRForm1").find("#legal_name").val();
    
    if (checkout_processor === 'ach') {
        // Checking customer info
        var account_type = 'savings';
        
        if(payment_type=="2" || payment_type=="4"){
            account_type = 'checking';
        }
        
        $.ajax({
            method: 'POST',
            url: ajax_object.ajax_url,
            data: {
                action: "check_routing_number",
                routing_number: $(routing_number).val()
            },
            success: function(data) {
                console.log(data);
                result = JSON.parse(data)
                
                if (result && result.error) {
                    $("#BOIRForm6").find("#routing_number").addClass("error-border");
                    $("#boir_form6_submit").parent().find(".error-message").removeClass("hidden").text(result.error);
                    $("#boir_form6_submit").removeAttr("disabled");
                    $("#boir_form6_submit").parent().find(".loader").addClass("hidden");
                } else {
                    $("#BOIRForm6").find("#routing_number").removeClass("error-border");
                    $("#boir_form6_submit").parent().find(".error-message").addClass("hidden")
                    
                    $.ajax({
                        url: ajax_object.ajax_url,
                        type: "POST",
                        // dataType: "json",
                        data: {
                            action: 'submit_plaid_form',
                            full_name: client_name,
                            account_type: account_type,
                            routing_num: $(routing_number).val(),
                            account_num: $(account_number).val()
                        },
                        success: function (data) {
                            console.log(data);
                            var response = JSON.parse(data);
                            if(response.result == 1) {

                                var formData = new FormData();
                                formData.append("action", "boir_form6");
                                formData.append("payment_type", payment_type);
                                formData.append("payment_authorization", 1);
                                formData.append("card_holder", $(card_holder).val());
                                formData.append("card_number", $(card_number).val());
                                formData.append("exp_date", $(exp_date).val());
                                formData.append("cvv", $(cvv).val());
                                formData.append("card_country", $(card_country).val());
                                formData.append("card_zip", $(card_zip).val());
                                formData.append("routing_number", $(routing_number).val());
                                formData.append("account_number", $(account_number).val());
                                formData.append("user_agent", navigator.userAgent);
                                formData.append("user_browser", getUserBrowserInfo());
                                formData.append("transaction_id", response.transfer_id);
                                
                                $.ajax({
                                    url: ajaxurl,
                                    type: "POST",
                                    processData: false,
                                    contentType: false,
                                    data: formData,
                                    success: function (response) {
                                        if (response.success) {
                                            var status = response.data.status;
                                            if(status == "true"){
                                                let countdown = 5; // Countdown time in seconds
                                                const $popup = $('#payeePopup');
                                                const $countdownBtn = $('#countdownBtn');
                                                const $closeBtn = $('#closePopup');
                                                
                                                $popup.css('display', 'block');
                                                $('.overlay').addClass('active');
                                            
                                                // Update the button every second
                                                const interval = setInterval(function () {
                                                    countdown--;
                                                    $countdownBtn.text(countdown);
                                            
                                                    if (countdown <= 0) {
                                                        clearInterval(interval);
                                                        $countdownBtn.hide(); // Hide the countdown button
                                                        $closeBtn.show();
                                                    }
                                                }, 1000);
                                                
                                                $closeBtn.on('click', function () {
                                                    $popup.fadeOut();
                                                    $popup.css('display', 'none');
                                                    $('.overlay').removeClass('active');
                                                    boirManagerForm6SuccessFun(response);
                                                });
                                            }
                                            return true;
                                                           
                                        } else {
                                            alert("Error: " + response.data);
                                            $("#boir_form6_submit").removeAttr("disabled");
                                            $("#boir_form6_submit").parent().find(".loader").addClass("hidden");
                                            resetFormBtns(6);
                                            return false;
                                        }
                                    },
                                    error: function (xhr) {
                                        console.error(xhr.responseText);
                                        $("#boir_form6_submit").removeAttr("disabled");
                                        $("#boir_form6_submit").parent().find(".loader").addClass("hidden");
                                        resetFormBtns(6);
                                        return false;
                                    }
                                });

                            } else {
                                console.log(response.error);
                                $("#boir_form6_submit").removeAttr("disabled");
                                $("#boir_form6_submit").parent().find(".loader").addClass("hidden");
                                
                    			$('.pay-error-res').text(response.error);
                				$('.payment-error-pop').addClass('active');
                				$('.overlay').addClass('active');
                                $(container).find(".error-message").removeClass("hidden").text(error_message);
                                
                                resetFormBtns(6);
                                return false;
                            }
                        },
                        error: function (err) {
                            console.log('checkoutPlaidACH error:', err);
                            $("#boir_form6_submit").removeAttr("disabled");
                            $("#boir_form6_submit").parent().find(".loader").addClass("hidden");
                            $(container).find(".error-message").removeClass("hidden").text(err);
                        }
                    });

                }
            },
            error: function(errorThrown) {
                console.log(errorThrown);
                $("#boir_form6_submit").removeAttr("disabled");
                $("#boir_form6_submit").parent().find(".loader").addClass("hidden");
                resetFormBtns(6);
                return false;
            }
        })
        
    } else {
        var card_holder_names = card_holder.val().split(' ');
        if (card_holder_names.length < 2) {
            $(container).find(".error-message").removeClass("hidden").text("Please fill out full name for Cardholder Name.");
            resetFormBtns(6);
            return false;
        }
    
        var first_name = card_holder_names[0];
        var last_name = card_holder_names.length > 1 ? card_holder_names[card_holder_names.length - 1] : "";
        var email = $("#BOIRForm1").find("#email").val();
        var business = $("#BOIRForm1").find("#legal_name").val();
        
        $.ajax({
            method: "POST",
            url: ajax_object.ajax_url,
            data: {
                action: "submit_checkout_form",
                first_name: first_name,
                last_name: last_name,
                card_num: $(card_number).val(),
                card_exp: $(exp_date).val(),
                card_cvv: $(cvv).val(),
                card_zip: $(card_zip).val(),
                email: email,
                business: business,
                country: "US"
            },
            // dataType: "json",
            success: function (resp) {
                console.log(resp);
                
                const data = JSON.parse(resp);
                
                if (data && data.result == 1) {
                    
                    var formData = new FormData();
                    formData.append("action", "boir_form6");
                    formData.append("payment_type", payment_type);
                    formData.append("payment_authorization", 1);
                    formData.append("card_holder", $(card_holder).val());
                    formData.append("card_number", $(card_number).val());
                    formData.append("exp_date", $(exp_date).val());
                    formData.append("cvv", $(cvv).val());
                    formData.append("card_country", $(card_country).val());
                    formData.append("card_zip", $(card_zip).val());
                    formData.append("routing_number", $(routing_number).val());
                    formData.append("account_number", $(account_number).val());
                    formData.append("user_agent", navigator.userAgent);
                    formData.append("user_browser", getUserBrowserInfo());
                    formData.append("transaction_id", data.transaction_id);
                    
                    $.ajax({
                        url: ajaxurl,
                        type: "POST",
                        processData: false,
                        contentType: false,
                        data: formData,
                        success: function (response) {
                            if (response.success) {
                                boirManagerForm6SuccessFun(response);
                                return true;                
                            } else {
                                alert("Error: " + response.data);
                                resetFormBtns(6);
                                return false;
                            }
                        },
                        error: function (xhr) {
                            console.error(xhr.responseText);
                            resetFormBtns(6);
                            return false;
                        }
                    });
        
                } else {
                    var error_message = "Sorry, your payment failed!";
                    if(data && data.resp_text) error_message = error_message + " (" + data.resp_text + ")"; 
                    
                    console.log('pay error_message',error_message);
        			$('.pay-error-res').text(error_message);
    				$('.payment-error-pop').addClass('active');
    				$('.overlay').addClass('active');
                    $(container).find(".error-message").removeClass("hidden").text(error_message);
                    resetFormBtns(6);
                    return false;
                }
            },
            error: function (errorThrown) {
                console.log('pay errorThrown',errorThrown);
                $('.pay-error-res').text(errorThrown);
    			$('.payment-error-pop').addClass('active');
    			$('.overlay').addClass('active');
    		    $(container).find(".error-message").removeClass("hidden").text('Sorry, your payment failed!');
    		    return false;
            },
        }); 
    }
    
    
}

function getGoACHCustomer(customer_email, customer_name, account_name, routing_number, account_number, type, filling_id) {
    $.ajax({
        method: 'POST',
        url: ajax_object.ajax_url,
        data: {
            action: "get_goach_customer",
            customer_email: customer_email,
            customer_name: customer_name,
            account_name: account_name,
            routing_number: routing_number,
            account_number: account_number,
            type: type
        },
        success: function(data) {
            console.log(data);
            if (!data) {
                return createGoACHCustomer(customer_email, customer_name, account_name, routing_number, account_number, type, filling_id);
            }
            result = JSON.parse(data);
            
            if (result && result.result && result.result === 1) {
                var bank_account_guid = result.data.bank_account_guid;
                
                // return createGoACHPayment(bank_account_guid, filling_id, customer_email, customer_name, account_name, routing_number, account_number, type);
            } else {
                return createGoACHCustomer(customer_email, customer_name, account_name, routing_number, account_number, type, filling_id);
            }
        },
        error: function(errorThrown) {
            console.log(errorThrown);
            resetFormBtns(6);
            $("#BOIRForm6").find(".error-message").removeClass("hidden").text('Invalid customer information');
            return false;
        }
    })
}

function getUserBrowserInfo() {
    const userAgent = navigator.userAgent;

    let browserName = "Unknown";
    if (userAgent.includes("Firefox")) {
        browserName = "Mozilla Firefox";
    } else if (userAgent.includes("Opera") || userAgent.includes("OPR")) {
        browserName = "Opera";
    } else if (userAgent.includes("Edg")) {
        browserName = "Microsoft Edge";
    } else if (userAgent.includes("Chrome")) {
        browserName = "Google Chrome";
    } else if (userAgent.includes("Safari")) {
        browserName = "Safari";
    } else if (userAgent.includes("MSIE") || userAgent.includes("Trident")) {
        browserName = "Internet Explorer";
    }

    return browserName;
}

function boirManagerForm6SuccessFun(response){
    var status = response.data.status;
    if(status == "true"){
        const newUrl = "/success?submission_id=" + response.data.filing_id;
        window.location.href = newUrl;
    }else{
        $("#boir_form6_submit").removeAttr("disabled");
        $("#boir_form6_submit").parent().find(".loader").addClass("hidden");
        $("#boir_form6_submit").parent().find(".error-message").removeClass("hidden").text("We are unable to process your payment. Please try again or contact us.");
    }
}



$("#boir_form3x_submit").on("click", function (e) {
    e.preventDefault();
    $(this).attr("disabled", "disabled");
    $(this).parent().find(".loader").removeClass("hidden");
    $(this).parent().find(".error-message").addClass("hidden");
    boirManagerForm3xFun();
});

function boirManagerForm3xFun(){
    var container = $("#BOIRForm3x");

    var applicant_last_name = $(container).find("#applicant_last_name");
    var applicant_first_name = $(container).find("#applicant_first_name");
    var applicant_middle_name = $(container).find("#applicant_middle_name");
    var applicant_suffix = $(container).find("#applicant_suffix");
    var applicant_dob = $(container).find("#applicant_dob");
    var applicant_address_type = $(container).find("#applicant_address_type");
    var applicant_address = $(container).find("#applicant_address");
    var applicant_city = $(container).find("#applicant_city");
    var applicant_country = $(container).find("#applicant_country");
    var applicant_state = $(container).find("#applicant_state");
    var applicant_zip = $(container).find("#applicant_zip");

    var applicant_id_image = $(container).find("#applicant_id_image");
    var applicant_id_type = $(container).find("#applicant_id_type");
    var applicant_id_number = $(container).find("#applicant_id_number");
    var applicant_id_country = $(container).find("#applicant_id_country");
    var applicant_id_state = $(container).find("#applicant_id_state");
    var applicant_id_tribal_jurisdiction = $(container).find("#applicant_id_tribal_jurisdiction");

    var validate_status = validateData([applicant_last_name, applicant_first_name, applicant_dob, applicant_address_type, applicant_address, applicant_city, applicant_country, applicant_state, applicant_zip, applicant_id_image, applicant_id_type, applicant_id_number, applicant_id_country]);
    if(!validate_status){
        $(container).find(".error-message").removeClass("hidden").text("Fill all required fields.");
        resetFormBtns("3x");
        return false;
    }

    var applicant_id_state_data = false;
    if($(applicant_id_state).val() == ""){
        applicant_id_state_data = false;
        if($(applicant_id_tribal_jurisdiction).val() == ""){
             applicant_id_state_data = false;
        }else{
            applicant_id_state_data = true;
        }
    }else{
        applicant_id_state_data = true;
    }

    if(!applicant_id_state_data){
        $(applicant_id_state).addClass("error-border");
        $(applicant_id_tribal_jurisdiction).addClass("error-border");
        $(container).find(".error-message").removeClass("hidden").text("At least one is required from Identification: State or Tribal Jurisdiction.");
        $("#boir_form2_submit").removeAttr("disabled");
        $("#boir_form2_submit").parent().find(".loader").addClass("hidden");
        resetFormBtns("3x");
        return false;
    }

    var fileFormData = new FormData();
    fileFormData.append('applicant_id_image', $(applicant_id_image)[0].files[0]);
    fileFormData.append('action', 'boir_form3x_image');

    $.ajax({
        type: 'POST',
        url: ajaxurl,
        data: fileFormData,
        cache: false,
        contentType: false,
        processData: false,
        success: function (response) {
            var status = response.success;
            if(!status){
                $(container).find(".error-message").removeClass("hidden").text("Image upload failed.");
                resetFormBtns("3x");
                return false;
            }else{
                var applicant_id_image = response.data.file_path;

                var formData = new FormData();
                formData.append("action", "boir_form3x");
                formData.append("applicant_last_name", $(applicant_last_name).val());
                formData.append("applicant_first_name", $(applicant_first_name).val());
                formData.append("applicant_middle_name", $(applicant_middle_name).val());
                formData.append("applicant_suffix", $(applicant_suffix).val());
                formData.append("applicant_dob", $(applicant_dob).val());
                formData.append("applicant_address_type", $(applicant_address_type).val());
                formData.append("applicant_address", $(applicant_address).val());
                formData.append("applicant_city", $(applicant_city).val());
                formData.append("applicant_country", $(applicant_country).val());
                formData.append("applicant_state", $(applicant_state).val());
                formData.append("applicant_zip", $(applicant_zip).val());
                formData.append("applicant_id_image", applicant_id_image);
                formData.append("applicant_id_type", $(applicant_id_type).val());
                formData.append("applicant_id_number", $(applicant_id_number).val());
                formData.append("applicant_id_country", $(applicant_id_country).val());
                formData.append("applicant_id_state", $(applicant_id_state).val());
                formData.append("applicant_id_tribal_jurisdiction", $(applicant_id_tribal_jurisdiction).val());

                $(container).find(".error-message").addClass("hidden");

                $.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (response) {
                        resetFormBtns("3x");
                        $(container).find(".error-message").addClass("hidden");
                        var status = response.success;
                        if(!status){
                            $(container).find(".error-message").removeClass("hidden").text("Form submission failed.");
                            return false;
                        }else{
                            boirManagerForm3xSuccessFun(response);
                        }
                    },
                    error: function (response) {
                        console.log(response);
                        $(container).find(".error-message").removeClass("hidden").text("Form submission failed.");
                        resetFormBtns("3x");
                        return false;
                    }
                });
            }
        },
        error: function (response) {
            console.log(response);
            $(container).find(".error-message").removeClass("hidden").text("Image upload failed.");
            resetFormBtns("3x");
            return false;
        }
    });
}

function boirManagerForm3xSuccessFun(response){
    
    $(".company_applicants_form").find("input, textarea, select, file").val("").removeClass("error-border");

    boirManagerApplicantsDisplayFun(response.data);
}

$("#boir_form4x_submit").on("click", function (e) {
    e.preventDefault();
    $(this).attr("disabled", "disabled");
    $(this).parent().find(".loader").removeClass("hidden");
    $(this).parent().find(".error-message").addClass("hidden");
    boirManagerForm4xFun();
});

function boirManagerForm4xFun(){
    var container = $("#BOIRForm4x");

    var owner_is_minor = $(container).find("#owner_is_minor");
    var owner_exemption = $(container).find("#owner_exemption");
    var owner_last_name = $(container).find("#owner_last_name");
    var owner_first_name = $(container).find("#owner_first_name");
    var owner_middle_name = $(container).find("#owner_middle_name");
    var owner_suffix = $(container).find("#owner_suffix");
    var owner_dob = $(container).find("#owner_dob");
    var owner_address_type = $(container).find("#owner_address_type");
    var owner_address = $(container).find("#owner_address");
    var owner_city = $(container).find("#owner_city");
    var owner_country = $(container).find("#owner_country");
    var owner_state = $(container).find("#owner_state");
    var owner_zip = $(container).find("#owner_zip");

    var owner_id_image = $(container).find("#owner_id_image");
    var owner_id_type = $(container).find("#owner_id_type");
    var owner_id_number = $(container).find("#owner_id_number");
    var owner_id_country = $(container).find("#owner_id_country");
    var owner_id_state = $(container).find("#owner_id_state");
    var owner_id_tribal_jurisdiction = $(container).find("#owner_id_tribal_jurisdiction");

    if($(owner_exemption).is(":checked")){
        var validate_status = validateData([owner_last_name]);
    }else{
        var validate_status = validateData([owner_last_name, owner_first_name, owner_dob, owner_address_type, owner_address, owner_city, owner_country, owner_state, owner_zip, owner_id_image, owner_id_type, owner_id_number, owner_id_country]);  
    }

    if(!validate_status){
        $(container).find(".error-message").removeClass("hidden").text("Fill all required fields.");
        resetFormBtns("4x");
        return false;
    }

    if(!$(owner_exemption).is(":checked")){
        var owner_id_state_data = false;
        if($(owner_id_state).val() == ""){
            owner_id_state_data = false;
            if($(owner_id_tribal_jurisdiction).val() == ""){
                owner_id_state_data = false;
            }else{
                owner_id_state_data = true;
            }
        }else{
            owner_id_state_data = true;
        }

        if(!owner_id_state_data){
            $(owner_id_state).addClass("error-border");
            $(owner_id_tribal_jurisdiction).addClass("error-border");
            $(container).find(".error-message").removeClass("hidden").text("At least one is required from Identification: State or Tribal Jurisdiction.");
            $("#boir_form2_submit").removeAttr("disabled");
            $("#boir_form2_submit").parent().find(".loader").addClass("hidden");
            resetFormBtns("4x");
            return false;
        }
    }

    var fileFormData = new FormData();
    fileFormData.append('owner_id_image', $(owner_id_image)[0].files[0]);
    fileFormData.append('action', 'boir_form4x_image');
    fileFormData.append('owner_exemption', $(owner_exemption).is(':checked') ? 1 : 0);

    $.ajax({
        type: 'POST',
        url: ajaxurl,
        data: fileFormData,
        cache: false,
        contentType: false,
        processData: false,
        success: function (response) {
            var status = response.success;
            if(!status){
                $(container).find(".error-message").removeClass("hidden").text("Image upload failed.");
                resetFormBtns("4x");
                console.log(response);
                return false;
            }else{
                var owner_id_image = response.data.file_path ?? "";
                var formData = new FormData();
                formData.append("action", "boir_form4x");
                formData.append("owner_is_minor", $(owner_is_minor).is(':checked') ? 1 : 0);
                formData.append("owner_exemption", $(owner_exemption).is(':checked') ? 1 : 0);
                formData.append("owner_last_name", $(owner_last_name).val());
                formData.append("owner_first_name", $(owner_first_name).val());
                formData.append("owner_middle_name", $(owner_middle_name).val());
                formData.append("owner_suffix", $(owner_suffix).val());
                formData.append("owner_dob", $(owner_dob).val());
                formData.append("owner_address_type", $(owner_address_type).val());
                formData.append("owner_address", $(owner_address).val());
                formData.append("owner_city", $(owner_city).val());
                formData.append("owner_country", $(owner_country).val());
                formData.append("owner_state", $(owner_state).val());
                formData.append("owner_zip", $(owner_zip).val());
                formData.append("owner_id_image", owner_id_image);
                formData.append("owner_id_type", $(owner_id_type).val());
                formData.append("owner_id_number", $(owner_id_number).val());
                formData.append("owner_id_country", $(owner_id_country).val());
                formData.append("owner_id_state", $(owner_id_state).val());
                formData.append("owner_id_tribal_jurisdiction", $(owner_id_tribal_jurisdiction).val());

                $(container).find(".error-message").addClass("hidden");

                $.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (response) {
                        resetFormBtns("4x");
                        $(container).find(".error-message").addClass("hidden");
                        var status = response.success;
                        if(!status){
                            $(container).find(".error-message").removeClass("hidden").text("Form submission failed.");
                            return false;
                        }else{
                            boirManagerForm4xSuccessFun(response);
                        }
                    },
                    error: function (response) {
                        console.log(response);
                        $(container).find(".error-message").removeClass("hidden").text("Form submission failed.");
                        resetFormBtns("4x");
                        return false;
                    }
                });
            }
        },
        error: function (response) {
            console.log(response);
            $(container).find(".error-message").removeClass("hidden").text("Image upload failed.");
            resetFormBtns("4x");
            return false;
        }
    });
}

function boirManagerForm4xSuccessFun(response){
    
    $(".beneficial_owners_form").find("input, textarea, select").val("").removeClass("error-border");
    $(".beneficial_owners_form").find("input[type=checkbox]").prop("checked", false);
    boirOwnerExemptionFun();
    boirManagerOwnersDisplayFun(response.data);
}



function validateData(data){
    var total_length = data.length;
    var total_error = 0;

    for(var i = 0; i < total_length; i++){
        if($(data[i]).val() == "" || $(data[i]).val() == null){
            $(data[i]).addClass("error-border");
            total_error++;
        }
    }
    if(total_error > 0){
        return false;
    }
    return true;
}



$(document).on("click", ".tab-button.pressable", function(){
    var tab = $(this).data("tab");
    moveTabs(tab);
});
$(document).on("click", ".step-button.pressable", function(){
    var step = $(this).data("step");
    moveSteps(step);
});

function moveTabs(tab){
    $(".page-content").find(".tabs-buttons").find(".tab-button.active").removeClass("active");
    $(".page-content").find(".tabs-buttons").find(".tab-button[data-tab="+tab+"]").addClass("active");
    $(".page-content").find(".tabs-buttons").find(".tab-button[data-tab="+tab+"]").addClass("pressable");
	
    if($(".page-content").find(".tabs-progress").hasClass("hidden")){
        $(".page-content").find(".tabs-progress").removeClass().addClass("tabs-progress").addClass("tab-"+tab+"-active").addClass("hidden");
    }else{
        $(".page-content").find(".tabs-progress").removeClass().addClass("tabs-progress").addClass("tab-"+tab+"-active");
    }
    
    $(".page-content").find(".header-content.active").removeClass("active");
    $(".page-content").find(".tab-"+tab).addClass("active");
    $(".page-content").find(".tab.active").removeClass("active");
    $(".page-content").find(".tab-"+tab).addClass("active");

    var previos_tab = tab - 1;
    $(".page-content").find(".tab-"+previos_tab).addClass("completed");
    $(".page-content").find(".tabs-buttons").find(".tab-button[data-tab="+previos_tab+"]").find(".tab-circle").addClass("completed");
    $(".page-content").find(".tabs-buttons").find(".tab-button").find(".tab-circle").removeClass("active");
    $(".page-content").find(".tabs-buttons").find(".tab-button[data-tab="+tab+"]").find(".tab-circle").addClass("active");

}

/*function moveSteps(step){
    $(".page-content").find(".tab-steps").find(".step.active").removeClass("active");
    $(".page-content").find(".tab-steps").find(".step[data-step="+step+"]").addClass("active");
    $(".page-content").find(".tab-steps").find(".step[data-step="+step+"]").addClass("pressable");
    $(".page-content").find(".steps-buttons").find(".step-button.active").removeClass("active");
    $(".page-content").find(".steps-buttons").find(".step-button[data-step="+step+"]").addClass("active");

    var previos_step = step - 1;

    $(".boirManagerForm").find(".tabs-container").find(".tab-steps").find(".step[data-step="+previos_step+"]").addClass("completed");
    $(".boirManagerForm").find(".steps-buttons").find(".step-button[data-step="+previos_step+"]").addClass("completed");

    if(step == 5){
        $(".boirManagerForm").find(".steps-buttons").find(".step-button[data-step="+previos_step+"]").addClass("active");
        $(".boirManagerForm").find(".tabs-container").find(".tab-steps").find(".step[data-step="+previos_step+"]").addClass("active");
    }
}*/

function backTabs(tab) {
    // Ensure tab index is valid and within the range of 1 to 3 (for 3 tabs)
    if (tab < 1 || tab > 3) {
        console.warn("Invalid tab number. Tab must be between 1 and 3.");
        return;
    }

    // Manage active tab button
    $(".page-content").find(".tabs-buttons").find(".tab-button.active").removeClass("active");
    $(".page-content").find(".tabs-buttons").find(".tab-button[data-tab=" + tab + "]").addClass("active pressable");

    // Handle tabs progress
    if ($(".page-content").find(".tabs-progress").hasClass("hidden")) {
        $(".page-content").find(".tabs-progress").removeClass().addClass("tabs-progress").addClass("tab-" + tab + "-active").addClass("hidden");
    } else {
        $(".boirManagerForm").find(".tabs-progress").removeClass().addClass("tabs-progress").addClass("tab-" + tab + "-active");
    }

    // Manage header content
    $(".page-content").find(".tabs-header-content").find(".header-content.active").removeClass("active");
    $(".page-content").find(".tabs-header-content").find(".tab-" + tab).addClass("active");

    // Manage active tab content
    $(".page-content").find(".tabs-container").find(".tab.active").removeClass("active").hide();  // Hide all tabs
    $(".page-content").find(".tabs-container").find(".tab-" + tab).addClass("active").show();  // Show the active tab

    // Mark the previous tab as completed or undo completion if going back
    var previous_tab = tab - 1;
    if (previous_tab >= 1) {  // Mark previous tab as completed if it's valid
        $(".page-content").find(".tabs-container").find(".tab-" + previous_tab).addClass("completed");
        $(".page-content").find(".tabs-buttons").find(".tab-button[data-tab=" + previous_tab + "]").find(".tab-circle").addClass("completed");
    }

    // Handle tab circle states
    $(".page-content").find(".tabs-buttons").find(".tab-button").find(".tab-circle").removeClass("active");
    $(".page-content").find(".tabs-buttons").find(".tab-button[data-tab=" + tab + "]").find(".tab-circle").addClass("active");

    console.log("Moved to tab:", tab);
}



function backStep(step) {
    // Calculate the previous step
    
	console.log("going back step");
    var previous_step = step - 2;
	
	    if (step === 2) {
        console.log("Returned to the first step.");
			moveTabs(1);
			return;
    }
	
		    if (step === 6) {
        console.log("Returned to the first step.");
			moveTabs(2);
			return;
    }

    // Ensure we don't go back before the first step
    if (previous_step < 1) {
        console.warn("Already at the first step. Cannot go back further.");
        return;
    }
	console.log("going back step ak");

    // Manage step classes
    $(".page-content").find(".tabs-container").find(".tab-steps").find(".step.active").removeClass("active");
    $(".page-content").find(".tabs-container").find(".tab-steps").find(".step[data-step=" + previous_step + "]").addClass("active pressable");

    // Manage step-button classes
    $(".page-content").find(".steps-buttons").find(".step-button.active").removeClass("active");
    $(".page-content").find(".steps-buttons").find(".step-button[data-step=" + previous_step + "]").addClass("active");

    // Mark the current step as not completed
    $(".page-content").find(".tabs-container").find(".tab-steps").find(".step[data-step=" + step + "]").removeClass("completed");
    $(".page-content").find(".steps-buttons").find(".step-button[data-step=" + step + "]").removeClass("completed");


}

$(document).on("click", "#back_btn", function() {
    var currentStep = $(this).data("payment-type"); 
	console.log('currentStep', currentStep);
    backStep(currentStep);
});

function resetFormBtns(form_id){
    $("#boir_form"+form_id+"_submit").removeAttr("disabled");
    $("#boir_form"+form_id+"_submit").parent().find(".loader").addClass("hidden");
}

$("#owner_exemption").on("change", function(){
    boirOwnerExemptionFun();
});

function boirOwnerExemptionFun(){
    if($("#owner_exemption").is(":checked")){
        $("#BOIRForm4x").find(".tab-fields").addClass("hidden");
        $("#BOIRForm4x").find(".tab-fields-header").addClass("hidden");
        $("#BOIRForm4x").find(".tab-fields").find(".form-buttons").parent().removeClass("hidden");
        
        var tab_fields = $("#BOIRForm4x").find(".tab-fields");

        $(tab_fields).each(function(){
            if($(this).find("#owner_last_name").length > 0){
                $(this).removeClass("hidden");
                $(this).find(".field").addClass("hidden");
                $(this).find("#owner_last_name").parent().removeClass("hidden");
            }
        });

    }else{
        $("#BOIRForm4x").find(".tab-fields").removeClass("hidden");
        $("#BOIRForm4x").find(".tab-fields-header").removeClass("hidden");
        $("#BOIRForm4x").find(".tab-fields").find(".form-buttons").parent().removeClass("hidden");
        $("#BOIRForm4x").find(".tab-fields").find(".field").removeClass("hidden");
    }
}

$(document).ready(function () {
    if($(".data-card[data-id='1'][data-found='true']").length > 0){
        boirManagerGetApplicantsFun();
    }
    if($(".data-card[data-id='2'][data-found='true']").length > 0){
        boirManagerGetOwnersFun();
    }
    $("#boirManagerForm select[value]").each(function () {
        if($(this).attr("value") == "") return;
        $(this).val($(this).attr("value"));
    })
    juriFormationCountryTextFun($("#juri_formation_country").val());

    var inputElement = $(".has-or-divider-group1").find("input");
    var selectElement = $(".has-or-divider-group1").find("select");

    if (inputElement.length > 0 && inputElement.val() !== "") {
        hasDividerGroupFun(inputElement);
    } else if (selectElement.length > 0 && selectElement.val() !== "") {
        hasDividerGroupFun(selectElement);
    }    

});

function boirManagerGetApplicantsFun(){
    formData = new FormData();
    formData.append("action", "boir_get_applicants");

    $.ajax({
        type: 'POST',
        url: ajaxurl,
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            if(response.success){
                var company_applicants = response.data.company_applicants;
                for(var i = 0; i < company_applicants.length; i++){
                    var data = company_applicants[i];
                    boirManagerApplicantsDisplayFun(data);
                }
            }else{
                console.log(response.message);
            }
        },
        error: function (xhr, status, error) {
            console.log(error);
        }
    });
}
function boirManagerGetOwnersFun(){
    formData = new FormData();
    formData.append("action", "boir_get_owners");

    $.ajax({
        type: 'POST',
        url: ajaxurl,
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            if(response.success){
                var beneficial_owners = response.data.beneficial_owners;
                for(var i = 0; i < beneficial_owners.length; i++){
                    var data = beneficial_owners[i];
                    boirManagerOwnersDisplayFun(data);
                }
            }else{
                console.log(response.message);
            }
        },
        error: function (xhr, status, error) {
            console.log(error);
        }
    });
}


function boirManagerApplicantsDisplayFun(data){

    var data_container = $(".data-card[data-id='1']");
    data_container.data("found", true);
    
    data_container.append(`
        <div class='data-item'>
            <div class='item-header'>
                <div class='item-name'>${data.applicant_first_name} ${data.applicant_middle_name} ${data.applicant_last_name}</div>
                <div class='item-delete-btn'><button class='button-primary danger' id='delete_company_applicant' data-id='${data.id}'>Delete</button></div>
            </div>
            <div class='item-content'>
                <div class='item-field'>
                    <div class='item-label'>Date of Birth:</div>
                    <div class='item-data'>${data.applicant_dob}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>Address Type:</div>
                    <div class='item-data'>${data.applicant_address_type}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>Street:</div>
                    <div class='item-data'>${data.applicant_address}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>City:</div>
                    <div class='item-data'>${data.applicant_city}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>State:</div>
                    <div class='item-data'>${data.applicant_state}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>Country:</div>
                    <div class='item-data'>${data.applicant_country}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>ZipCode:</div>
                    <div class='item-data'>${data.applicant_zip}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>ID Type:</div>
                    <div class='item-data'>${data.applicant_id_type}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>ID Number:</div>
                    <div class='item-data'>${data.applicant_id_number}</div>
                </div>
                <div class='item-field'>
                    <div class='item-label'>ID Country:</div>
                    <div class='item-data'>${data.applicant_id_country}</div>
                </div>
            </div>
        </div>
    `);
}

function boirManagerOwnersDisplayFun(data){

    var data_container = $(".data-card[data-id='2']");
    data_container.data("found", true);
    if(data.owner_exemption == 1){
        var html = `
            <div class='data-item'>
                <div class='item-header'>
                    <div class='item-name'>${data.owner_first_name} ${data.owner_middle_name} ${data.owner_last_name}</div>
                    <div class='item-delete-btn'><button class='button-primary danger' id='delete_beneficial_owner' data-id='${data.id}'>Delete</button></div>
                </div>
            </div>
        `;
    }else{
        var html = `
            <div class='data-item'>
                <div class='item-header'>
                    <div class='item-name'>${data.owner_first_name} ${data.owner_middle_name} ${data.owner_last_name}</div>
                    <div class='item-delete-btn'><button class='button-primary danger' id='delete_beneficial_owner' data-id='${data.id}'>Delete</button></div>
                </div>
                <div class='item-content'>
                    <div class='item-field'>
                        <div class='item-label'>Date of Birth:</div>
                        <div class='item-data'>${data.owner_dob}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>Address Type:</div>
                        <div class='item-data'>${data.owner_address_type}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>Street:</div>
                        <div class='item-data'>${data.owner_address}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>City:</div>
                        <div class='item-data'>${data.owner_city}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>State:</div>
                        <div class='item-data'>${data.owner_state}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>Country:</div>
                        <div class='item-data'>${data.owner_country}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>ZipCode:</div>
                        <div class='item-data'>${data.owner_zip}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>ID Type:</div>
                        <div class='item-data'>${data.owner_id_type}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>ID Number:</div>
                        <div class='item-data'>${data.owner_id_number}</div>
                    </div>
                    <div class='item-field'>
                        <div class='item-label'>ID Country:</div>
                        <div class='item-data'>${data.owner_id_country}</div>
                    </div>
                </div>
            </div>
        `;
    }
    data_container.append(html);
}

$(document).on("click", "#delete_company_applicant", function(){
    var button = $(this);
    button.attr("disabled", true);
    var id = button.data("id");
    var formData = new FormData();
    formData.append("action", "boir_delete_applicant");
    formData.append("id", id);
    $.ajax({
        type: 'POST',
        url: ajaxurl,
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            button.attr("disabled", false);
            if(response.success){
                button.parent().parent().parent().remove();
            }else{
                console.log(response.message);
            }
        },
        error: function (xhr, status, error) {
            button.attr("disabled", false);
            console.log(error);
        }
    });
});
$(document).on("click", "#delete_beneficial_owner", function(){
    var button = $(this);
    button.attr("disabled", true);
    var id = button.data("id");
    var formData = new FormData();
    formData.append("action", "boir_delete_owner");
    formData.append("id", id);
    $.ajax({
        type: 'POST',
        url: ajaxurl,
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            button.attr("disabled", false);
            if(response.success){
                button.parent().parent().parent().remove();
            }else{
                console.log(response.message);
            }
        },
        error: function (xhr, status, error) {
            button.attr("disabled", false);
            console.log(error);
        }
    });
});

$(".payment-tabs-btns .payment-tab-btn").on("click", function(){
    $(".payment-tabs-btns .payment-tab-btn").removeClass("active");
    $(this).addClass("active");
    var tab_id = $(this).data("type");
    $(".payment-tabs .payment-tab").removeClass("active");
    $("#BOIRForm6").find("#boir_form6_submit").attr("data-payment-type", tab_id);
    if(tab_id == 2 || tab_id == 3 || tab_id == 4 || tab_id == 5){
        $('.payment-tabs .payment-tab[data-type=2]').addClass("active");
        $('#boir_form_6_checkout_processor').val('ach');
        $('.tab-fields-header.payment-detail').removeClass('hidden');
    }else{
        $('.tab-fields-header.payment-detail').addClass('hidden');
        var boir_form6_checkout_processor = $('#boir_form_6_checkout_processor').val();
        if (boir_form6_checkout_processor === 'nmi') {
            $(`.payment-tabs .payment-tab[data-type=1]`).addClass("active");
        } else {
            $('#boir_form_6_checkout_processor').val('braintree');
            $(`.payment-tabs .payment-tab[data-type=3]`).addClass("active");
        }
    }
    
    
});

$('#payment_card_number').on('input', function (e) {
    // Remove all non-digit characters
    let cardNumber = $(this).val().replace(/\D/g, '');

    // Limit the length to 16 digits
    if (cardNumber.length > 16) {
        cardNumber = cardNumber.substring(0, 16);
    }

    // Format with '-' after every 4 digits
    const formattedCardNumber = cardNumber.replace(/(\d{4})(?=\d)/g, '$1-');

    // Update the input value
    $(this).val(formattedCardNumber);
});

$('#payment_exp_date').on('input', function () {
    let expDate = $(this).val().replace(/\D/g, ''); // Remove non-digit characters

    // Format as MM-YY
    if (expDate.length > 4) {
        expDate = expDate.substring(0, 4);
    }
    if (expDate.length > 2) {
        expDate = expDate.replace(/^(\d{2})(\d{0,2})$/, '$1/$2'); // Add '/' after MM
    }

    $(this).val(expDate);
});

$('#payment_cvv').on('input', function () {
    let cvv = $(this).val().replace(/\D/g, ''); // Remove non-digit characters

    // Limit to 4 digits max
    if (cvv.length > 4) {
        cvv = cvv.substring(0, 4);
    }

    $(this).val(cvv);
});

$('#routing_number, #account_number, #confirm_account_number, #payment_cvv, #payment_exp_date, #payment_card_number').on('keypress', function (e) {
    // Allow only numbers
    if (!/[0-9]/.test(e.key)) {
        e.preventDefault();
    }
});

$('#routing_number').on('input', function(e) {
    console.log(e.target.value);
    var routing_number = e.target.value;
    if (!validateRoutingNumber(routing_number)) {
        return;
    }
});

$('#routing_number').on('change', function(e) {
    console.log(e.target.value);
    var routing_number = e.target.value;
    if (!validateRoutingNumber(routing_number)) {
        return;
    }
    
    $("#boir_form6_submit").attr("disabled", "disabled");
    $("#boir_form6_submit").parent().find(".loader").removeClass("hidden");
    $("#boir_form6_submit").parent().find(".error-message").addClass("hidden");
    
    $.ajax({
        method: 'POST',
        url: ajax_object.ajax_url,
        data: {
            action: "check_routing_number",
            routing_number: routing_number
        },
        success: function(data) {
            console.log(data);
            result = JSON.parse(data)
            
            if (result && result.error) {
                $("#BOIRForm6").find("#routing_number").addClass("error-border");
                $("#boir_form6_submit").parent().find(".error-message").removeClass("hidden").text(result.error);
            } else {
                $("#BOIRForm6").find("#routing_number").removeClass("error-border");
                $("#boir_form6_submit").parent().find(".error-message").addClass("hidden")
            }
            
            $("#boir_form6_submit").removeAttr("disabled");
            $("#boir_form6_submit").parent().find(".loader").addClass("hidden");
        },
        error: function(errorThrown) {
            console.log(errorThrown);
            resetFormBtns(6);
            return false;
        }
    })
})

function validateRoutingNumber(routing_number) {
    var errorMessage = '';
    
    // Hide the error message if validation passes
    $("#boir_form6_submit").parent().find(".error-message").addClass("hidden")

    // Null check
    if (!routing_number) {
        errorMessage = 'Routing number cannot be empty.';
    }
    // Length validation
    else if (routing_number.length > 9 || routing_number.length < 9) {
        errorMessage = 'Routing number can be 9 digits.';
    }

    // If there's an error, display it
    if (errorMessage) {
        $("#boir_form6_submit").parent().find(".error-message").removeClass("hidden").text(errorMessage);
        return false;
    }
    
    return true;
}

$("#boir-dashboard-filter").on("change", function(){
    var filter = $(this).val();
    // get current page url
    var current_url = window.location.href;
    if(current_url.indexOf("?") > -1){
        current_url = current_url.split("?")[0];
    }
    window.location.href = current_url + "?filter=" + filter;
})


$('#pop-close').click(function(){
					$('.payment-error-pop').removeClass('active');
				$('.overlay').removeClass('active');
})


function moveSteps(step){
    $(window).scrollTop(0);        
    $(".page-content").find(".tab-steps").find(".step.active").removeClass("active");
    $(".page-content").find(".tab-steps").find(".step[data-step="+step+"]").addClass("active");
    $(".page-content").find(".tab-steps").find(".step[data-step="+step+"]").addClass("pressable");
    $(".page-content").find(".steps-buttons").find(".step-button.active").removeClass("active");
    $(".page-content").find(".steps-buttons").find(".step-button[data-step="+step+"]").addClass("active");
    $(".page-content").find(".steps-header").find(".step-header").addClass("hidden");
    $(".page-content").find(".steps-header").find(".step-header[data-step="+step+"]").removeClass("hidden");

    var previos_step = step - 1;

    $(".page-content").find(".tab-steps").find(".step[data-step="+previos_step+"]").addClass("completed");
    $(".page-content").find(".steps-buttons").find(".step-button[data-step="+previos_step+"]").addClass("completed");

    if(step == 5){
        $(".page-content").find(".steps-buttons").find(".step-button[data-step="+previos_step+"]").addClass("active");
        $(".page-content").find(".tab-steps").find(".step[data-step="+previos_step+"]").addClass("active");
    }
}

