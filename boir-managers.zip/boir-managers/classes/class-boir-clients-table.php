<?php

// class-boir-clients-table.php

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class BOIR_Clients_Table extends WP_List_Table {

    private $data;

    public function __construct() {
        parent::__construct([
            'singular' => 'filling',
            'plural'   => 'fillings',
            'ajax'     => true,
        ]);
    
        // Set default order parameters
        if (!isset($_GET['orderby'])) {
            $_GET['orderby'] = 'id';
        }
        if (!isset($_GET['order'])) {
            $_GET['order'] = 'desc';
        }
    }

    public function prepare_items() {
        global $wpdb;
    
        $table_name = $wpdb->prefix . 'boir_clients_fillings';
    
        // Handle bulk actions
        if (isset($_POST['action']) && $_POST['action'] === 'delete' && !empty($_POST['ids'])) {
            $ids = array_map('intval', $_POST['ids']);
            $ids_placeholder = implode(',', array_fill(0, count($ids), '%d'));
            $query = "DELETE FROM $table_name WHERE id IN ($ids_placeholder)";
            $wpdb->query($wpdb->prepare($query, $ids));
        }
    
        // Sorting parameters
        $orderby = isset($_GET['orderby']) ? sanitize_sql_orderby($_GET['orderby']) : 'id';
        $order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : 'desc';
    
        // Search parameter
        $search = isset($_POST['s']) ? sanitize_text_field($_POST['s']) : '';


        // $table_clients_fillings = $wpdb->prefix . 'boir_clients_fillings';
        $table_clients = $wpdb->prefix . 'boir_clients';

        // Query the database
        $query = "SELECT id, user_id, client_name, client_email, client_phone, client_conversion_from, created_at
                  FROM $table_clients
                  WHERE 1=1";
        
        $conditions = [];
        $queryParams = [];

        if (!empty($search)) {
            $conditions[] = "(client_name LIKE %s OR client_email LIKE %s OR client_phone LIKE %s OR client_conversion_from LIKE %s)";
            $queryParams[] = '%' . $wpdb->esc_like($search) . '%';
            $queryParams[] = '%' . $wpdb->esc_like($search) . '%';
            $queryParams[] = '%' . $wpdb->esc_like($search) . '%';
            $queryParams[] = '%' . $wpdb->esc_like($search) . '%';
        }

        if (!empty($conditions)) {
            $query .= " AND " . implode(" AND ", $conditions);
        }

        $query .= " ORDER BY $orderby $order";

        if (!empty($queryParams)) {
            $query = $wpdb->prepare($query, ...$queryParams);
        }

        // Execute the query
        $this->data = $wpdb->get_results($query, ARRAY_A);

        // Pagination
        $per_page = 10;
        $current_page = $this->get_pagenum();
        $total_items = count($this->data);

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page),
        ]);
    
        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $primary  = 'client_name';
        $this->_column_headers = array($columns, $hidden, $sortable, $primary);
    
        $this->data = array_slice($this->data, (($current_page - 1) * $per_page), $per_page);
        $this->items = $this->data;
    }

    public function get_columns() {
        return [
            'cb'            => '<input type="checkbox" />', // Checkbox for bulk actions
            'client_name'  => 'Client Name',
            'client_email' => 'Client Email',
            'client_phone' => 'Client Phone',
            'client_conversion_from' => 'Conversion From',
            'created_at'    => 'Created At'
        ];
    }

    protected function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="ids[]" value="%s" />',
            $item['id']
        );
    }

    protected function get_bulk_actions() {
        return [
            'delete' => 'Delete'
        ];
    }

    protected function column_default($item, $column_name) {
        switch ($column_name) {
            case 'id':
            case 'client_name':
            case 'client_email':
            case 'client_phone':
            case 'created_at':
                return $item[$column_name];
            case 'client_conversion_from':
                return '<a href="' . $item[$column_name] . '" target="_blank">' . $item[$column_name] . '</a>';
            default:
                return print_r($item, true); // For debugging unexpected columns
        }
    }

    protected function column_client_name($item) {
        $title = sprintf('<a href="%s"><strong>%s</strong></a>', admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=view&id={$item['id']}"), $item['client_name']);
        $view_url = admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=view&id={$item['id']}");
        $edit_url = admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=edit&id={$item['id']}");
        $delete_url = admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=delete&id={$item['id']}");

        $actions = [
            'view' => sprintf('<a href="%s">View</a>', $view_url),
            'delete' => sprintf('<a href="%s" onclick="return confirm(\'Are you sure you want to delete this?\')">Delete</a>', $delete_url),
        ];

        return sprintf('%1$s %2$s',
            /*$1%s*/ $title,          
            /*$2%s*/ $this->row_actions($actions)
        );
    }

    public function get_sortable_columns() {
        return [
            'client_name' => ['client_name', false],
            'client_email' => ['client_email', false],
            'client_conversion_from' => ['client_conversion_from', false],
            'created_at' => ['created_at', false],
        ];
    }

    public function no_items() {
        _e('No fillings found.');
    }
}

