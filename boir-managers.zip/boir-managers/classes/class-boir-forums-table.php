<?php

// class-boir-fillings-table.php

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class BOIR_Forums_Table extends WP_List_Table {

    private $data;
    private $form_id;

    public function __construct() {
        parent::__construct([
            'singular' => 'filling',
            'plural'   => 'fillings',
            'ajax'     => true,
        ]);
        
        $this->form_id = -1;
    
        // Set default order parameters
        if (!isset($_GET['orderby'])) {
            $_GET['orderby'] = 'id';
        }
        if (!isset($_GET['order'])) {
            $_GET['order'] = 'desc';
        }
    }
    
    public function set_form_id($form_id) {
        $this->form_id = $form_id;
    }

    public function prepare_items() {
        if (!class_exists('FrmEntry')) {
            $this->items = [];
            return 0;
        }
        
        if ($this->form_id < 0) {
            $this->items = [];
            return;
        }
    
        // Fetch entries count for the specific form ID
        $args = [
            'form_id' => $this->form_id,
        ];
    
        // Use FrmEntry::getAll() to fetch entries and count them
        $entries = FrmEntry::getAll($args, '', '', true);
        
        if (empty($entries)) {
            $this->items = [];
            return;
        }
    
        // Parse the entries into a simpler structure
        if ($this->form_id == 3) {
            $parsed_entries = array_map(function ($item) {
                return [
                    'id'              => $item->id, // Access object property directly
                    'client_name'     => $item->metas['21'] ?? '', // Access metas
                    'client_email'    => $item->metas['22'] ?? '',
                    'client_phone'    => $item->metas['23'] ?? '',
                    'client_conversion_from' => 'Forum1', // Conversion source
                    'draft_status'  => $item->is_draft, // Status
                    'created_at'      => $item->created_at, // Creation date
                ];
            }, $entries);
        } else {
            $parsed_entries = array_map(function ($item) {
                return [
                    'id'              => $item->id, // Access object property directly
                    'client_name'     => $item->metas['40'] ?? '', // Access metas
                    'client_email'    => $item->metas['41'] ?? '',
                    'client_phone'    => $item->metas['42'] ?? '',
                    'client_conversion_from' => 'Forum2', // Conversion source
                    'draft_status'  => $item->is_draft, // Status
                    'created_at'      => $item->created_at, // Creation date
                ];
            }, $entries);
        }
        
        // Sorting parameters
        $orderby = isset($_GET['orderby']) ? sanitize_sql_orderby($_GET['orderby']) : 'id';
        $order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : 'desc';
    
        // Search parameter
        $search = isset($_POST['s']) ? sanitize_text_field($_POST['s']) : '';
        
        if (!empty($search)) {
            $search_term = strtolower($search);
            $parsed_entries = array_filter($parsed_entries, function ($entry) use ($search_term) {
                return stripos($entry['client_name'], $search_term) !== false ||
                       stripos($entry['client_email'], $search_term) !== false ||
                       stripos($entry['client_phone'], $search_term) !== false;
            });
        }
        
        usort($parsed_entries, function ($a, $b) use ($orderby, $order) {
            $value1 = $a[$orderby] ?? '';
            $value2 = $b[$orderby] ?? '';
    
            if ($order === 'asc') {
                return $value1 <=> $value2;
            } else {
                return $value2 <=> $value1;
            }
        });

        // Execute the query
        $this->data = $parsed_entries;

        // Pagination
        $per_page = 10;
        $current_page = $this->get_pagenum();
        $total_items = count($this->data);
    
        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page),
        ]);
    
        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $primary  = 'filling_code';
        $this->_column_headers = array($columns, $hidden, $sortable, $primary);
    
        $this->data = array_slice($this->data, (($current_page - 1) * $per_page), $per_page);
        $this->items = $this->data;
    }

    public function get_columns() {
        return [
            'cb'            => '<input type="checkbox" />', // Checkbox for bulk actions
            'client_name' => 'Client Name',
            'client_email' => 'Client Email',
            'client_phone' => 'Client Phone',
            'client_conversion_from' => 'Conversion From',
            'draft_status'=> 'Draft Status',
            'created_at'    => 'Created At'
        ];
    }

    protected function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="ids[]" value="%s" />',
            $item['id']
        );
    }

    protected function get_bulk_actions() {
        return [
            // 'delete' => 'Delete'
        ];
    }

    protected function column_default($item, $column_name) {
        switch ($column_name) {
            case 'id':
            case 'client_name':
                return $item[$column_name];
            case 'client_email':
                return $item[$column_name];
            case 'client_phone':
                return $item[$column_name];
            case 'created_at':
                return $item[$column_name];
            case 'client_conversion_from':
                return $item[$column_name];
            case 'draft_status':
                return $item[$column_name];
            // case 'filling_status':
            //     // Map status values to labels
            //     $statuses = [
            //         0 => '<span style="color: red; border: 1px solid red; padding: 2px 5px;text-transform: uppercase">Incomplete</span>',
            //         1 => '<span style="color: #FFA500; border: 1px solid #FFA500; padding: 2px 5px;text-transform: uppercase">In Progress</span>',
            //         2 => '<span style="color: green; border: 1px solid green; padding: 2px 5px;text-transform: uppercase">Completed</span>',
            //     ];
            //     return $statuses[$item['filling_status']] ?? 'Unknown';
            default:
                return print_r($item, true); // For debugging unexpected columns
        }
    }

    protected function column_title($item) {
        $title = sprintf('<a href="%s"><strong>%s</strong></a>', admin_url("admin.php?page=boir-manager-admin-menu&action=view&id={$item['id']}"), $item['filling_code']);
        $view_url = admin_url("admin.php?page=boir-manager-admin-menu&action=view&id={$item['id']}");
        $edit_url = admin_url("admin.php?page=boir-manager-admin-menu&action=edit&id={$item['id']}");
        $delete_url = admin_url("admin.php?page=boir-manager-admin-menu&action=delete&id={$item['id']}");

        $actions = [
            'view' => sprintf('<a href="%s">View</a>', $view_url),
            'delete' => sprintf('<a href="%s" onclick="return confirm(\'Are you sure you want to delete this?\')">Delete</a>', $delete_url),
        ];

        return sprintf('%1$s %2$s',
            /*$1%s*/ $title,          
            /*$2%s*/ $this->row_actions($actions)
        );
    }
    
    // protected function column_client_name($item) {
    //     $title = sprintf('<a href="%s"><strong>%s</strong></a>', admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=view&id={$item['client_id']}"), $item['client_name']);
    //     $view_url = admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=view&id={$item['client_id']}");
    //     $edit_url = admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=edit&id={$item['client_id']}");
    //     $delete_url = admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=delete&id={$item['client_id']}");

    //     $actions = [
    //         'view' => sprintf('<a href="%s">View</a>', $view_url),
    //     ];

    //     return sprintf('%1$s %2$s',
    //         /*$1%s*/ $title,          
    //         /*$2%s*/ $this->row_actions($actions)
    //     );
    // }

    public function get_sortable_columns() {
        return [
            'id'         => ['id', false],
            'draft_status' => ['draft_status', false],
            'created_at' => ['created_at', false],
        ];
    }

    public function no_items() {
        _e('No fillings found.');
    }
}

