<?php
function boir_manager_admin_menu()
{
    add_menu_page('BOIR Manager Dashboard','Boir Manager','manage_options','boir-manager-admin-menu','boir_manager_admin_menu_main','dashicons-screenoptions',2);
    add_submenu_page('boir-manager-admin-menu','BOIR Clients List','Clients List','manage_options','boir-manager-admin-menu-sub-clients-list','boir_manager_admin_menu_sub_clients_list');
    add_submenu_page('boir-manager-admin-menu', 'BOIR Forum1 List', 'Forum1 List', 'manage_options', 'boir-manager-admin-menu-sub-forum1-list', 'boir_manager_admin_menu_sub_forum1_list');
    add_submenu_page('boir-manager-admin-menu', 'BOIR Forum2 List', 'Forum2 List', 'manage_options', 'boir-manager-admin-menu-sub-forum2-list', 'boir_manager_admin_menu_sub_forum2_list');
    // add_submenu_page('boir-manager-admin-menu','LMS Orders List','Orders List','manage_options','zli-admin-menu-sub-orders-list','zli_admin_menu_sub_orders_list');
    // add_submenu_page('boir-manager-admin-menu','LMS Settings','Settings','manage_options','zli-admin-menu-sub-settings','zli_admin_menu_sub_settings');
}

add_action('admin_menu','boir_manager_admin_menu');
?>