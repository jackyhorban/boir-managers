<?php 

// Adjust settings

/*
 Hide Elementor Page title
 Comment the line below to unhide the page titles.
*/

function es_disable_page_title( $return ){ 
    if( is_page("file") || is_page("dashboard") || is_page("signin") ) {
        return false;
    }
    return $return;
}
add_filter( 'hello_elementor_page_title', 'es_disable_page_title' );

// Hide the admin bar for users with the role of Customer.

function remove_admin_bar_for_customer() {
    if (current_user_can('Customer')) {
        show_admin_bar(false);
    }
}
add_action('after_setup_theme', 'remove_admin_bar_for_customer');

// Force custom redirection for all customers

$boir_client_dashboard_url = home_url('/dashboard');
function enforce_custom_login_redirect($redirect_to, $requested_redirect_to, $user) {
    global $boir_client_dashboard_url;
    if (isset($user->roles) && in_array('Customer', $user->roles)) {
        return $boir_client_dashboard_url;
    }
    return $redirect_to;
}
add_filter('login_redirect', 'enforce_custom_login_redirect', 10, 3);

// Restrict access to the custom dashboard for users with the role of Customer

function restrict_customer_admin_access() {
    global $boir_client_dashboard_url;
    if (is_admin() && !defined('DOING_AJAX') && current_user_can('Customer')) {
        wp_redirect($boir_client_dashboard_url);
        exit;
    }
}
add_action('admin_init', 'restrict_customer_admin_access');

function custom_login_redirect_on_authenticate($user, $username, $password) {
    if (empty($username) || empty($password)) {
        $error_codes = [];
        if (empty($username)) {
            $error_codes[] = 'empty_username';
        }
        if (empty($password)) {
            $error_codes[] = 'empty_password';
        }

        // Redirect to the custom login page with error codes
        $error_param = !empty($error_codes) ? '&errors=' . implode(',', $error_codes) : '';
        wp_redirect(home_url('/signin') . '?login=failed' . $error_param);
        exit;
    }
    return $user;
}
add_filter('authenticate', 'custom_login_redirect_on_authenticate', 30, 3);

// Redirect to custom login page on authentication failure
function custom_login_failed_redirect($username) {
    $referrer = wp_get_referer();
    if ($referrer && strpos($referrer, 'signin') !== false) {
        $error_codes = array();

        if (empty($_POST['log'])) {
            $error_codes[] = 'empty_username';
        }
        if (empty($_POST['pwd'])) {
            $error_codes[] = 'empty_password';
        }

        if (!empty($_POST['log']) && !username_exists($_POST['log'])) {
            $error_codes[] = 'invalid_username';
        } elseif (!empty($_POST['log']) && !wp_check_password($_POST['pwd'], get_user_by('login', $_POST['log'])->user_pass, get_user_by('login', $_POST['log'])->ID)) {
            $error_codes[] = 'incorrect_password';
        }

        $error_param = !empty($error_codes) ? '&errors=' . implode(',', $error_codes) : '';
        wp_redirect(home_url('/signin') . '?login=failed' . $error_param);
        exit;
    }
}
add_action('wp_login_failed', 'custom_login_failed_redirect');
