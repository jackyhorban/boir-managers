<?php
require_once plugin_dir_path(__FILE__) . '../classes/class-boir-forums-table.php';

function boir_forum2_list_page() {
    echo '<div class="wrap">';
    echo '<h1 class="wp-heading-inline">BOIR Forum2 List</h1>';

    // Check if a status filter is set
    // $selected_status = isset($_GET['filling_status']) ? $_GET['filling_status'] : '';

    // Instantiate the table and prepare the items
    $table = new BOIR_Forums_Table();
    $table->set_form_id(4);
    $table->prepare_items();
    // $table->views();
    ?>
    <form method="post">
        <?php
            $table->search_box('Search', 'filling_search');
        ?>
    
    
    <?php
        $table->display();
        ?>
    </form>
</div>
<script>
    jQuery("#client_search-search-input").attr("placeholder", "Search Clients...");
</script>

<?php
}
    
boir_forum2_list_page();

?>