
<?php

// main.php

require_once plugin_dir_path(__FILE__) . '../classes/class-boir-fillings-table.php';

function boir_manager_list_page() {
    echo '<div class="wrap">';
    echo '<h1 class="wp-heading-inline">BOIR Fillings</h1>';
?>
    <div class="dashboard-header-cards" style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
        <div class="card" style="flex-grow: 1;">
            <h2 class="card-header" style="font-weight: bold; font-size: 40px;">
                <?php echo boir_manager_get_fillings_count('completed'); ?>
            </h2>
            <div class="card-body">
                Completed Fillings
            </div>
        </div>
        <div class="card" style="flex-grow: 1;">
            <h2 class="card-header" style="font-weight: bold; font-size: 40px;">
                <?php echo boir_manager_get_fillings_count('active'); ?>
            </h2>
            <div class="card-body">
                In Progress Fillings
            </div>
        </div>
        <div class="card" style="flex-grow: 1;">
            <h2 class="card-header" style="font-weight: bold; font-size: 40px;">
                <?php echo boir_manager_get_fillings_count('incomplete'); ?>
            </h2>
            <div class="card-body">
                InComplete Fillings
            </div>
        </div>
        <div class="card" style="flex-grow: 1;">
            <div style="display: flex; justify-content: space-between;">
                <div style="flex-grow: 2; border-right: solid; padding-right: 1rem;">
                    <h2 class="card-header" style="font-weight: bold; font-size: 40px;">
                        <?php echo boir_manager_get_clients_conversion_count_total(); ?>
                    </h2>
                    <div class="card-body">
                        Mailer Conversions
                    </div>
                </div>
                <div style="flex-grow: 2; padding-left: 1rem; display: flex; flex-direction: column; justify-content: space-around;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div style="font-weight: bold; font-size: 20px;">
                            <?php echo boir_manager_get_clients_conversion_count('file7/'); ?>
                        </div>
                        <div class="card-body">
                            Current
                        </div>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div style="font-weight: bold; font-size: 20px;">
                            <?php echo boir_manager_get_clients_conversion_count_forum(3); ?>
                        </div>
                        <div class="card-body">
                            Forum1
                        </div>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div style="font-weight: bold; font-size: 20px;">
                            <?php echo boir_manager_get_clients_conversion_count_forum(4); ?>
                        </div>
                        <div class="card-body">
                            Forum2
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card" style="flex-grow: 1;">
            <h2 class="card-header" style="font-weight: bold; font-size: 40px;">
                <?php echo boir_manager_get_clients_conversion_count('file/'); ?>
            </h2>
            <div class="card-body">
                Main Conversions
            </div>
        </div>

    </div>
<?php

    // Check if a status filter is set
    // $selected_status = isset($_GET['filling_status']) ? $_GET['filling_status'] : '';

    // Instantiate the table and prepare the items
    $table = new BOIR_Fillings_Table();
    $table->prepare_items();
    // $table->views();
    ?>
    <form method="post">
        <?php
        $table->search_box('Search', 'filling_search');
    ?>
    
    
    <?php
        $table->display();
        ?>
    </form>
</div>
<script>
    jQuery("#filling_search-search-input").attr("placeholder", "Search Filling...");
</script>

<?php
}


boir_manager_list_page();



function boir_manager_get_fillings_count($status) {
    if(!$status){
        return 0;
    }elseif($status == 'completed'){
        $filling_status = 2;
    }elseif($status == 'active'){
        $filling_status = 1;
    }elseif($status == 'incomplete'){
        $filling_status = 0;
    }else{
        return 0;
    }
    global $wpdb;
    $count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}boir_clients_fillings WHERE filling_status = {$filling_status}");
    return $count;
}

function boir_manager_get_clients_conversion_count($slug) {
    global $wpdb;
    $count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}boir_clients WHERE client_conversion_from LIKE '%{$slug}%'");
    return $count;
}

function boir_manager_get_clients_conversion_count_forum($form_id) {
    if (!class_exists('FrmEntry')) {
        return 0;
    }

    // Fetch entries count for the specific form ID
    $args = [
        'form_id' => $form_id,
    ];

    // Use FrmEntry::getAll() to fetch entries and count them
    $entries = FrmEntry::getAll($args, '', '', true);

    return count($entries);
}

function boir_manager_get_clients_conversion_count_total() {
    $total = 0;
    $total += boir_manager_get_clients_conversion_count('file7/');
    $total += boir_manager_get_clients_conversion_count_forum(3);
    $total += boir_manager_get_clients_conversion_count_forum(4);
    
    return $total;
}

?>
