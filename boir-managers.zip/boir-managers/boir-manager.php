<?php
/*
Plugin Name: BOIR Filling System
Plugin URI: https://boir.org
Description: Custom plugin for BOIR Filling System by BOIR.
Version: 0.0.1
Requires at least: 5.8
Requires PHP: 5.6.20
Author: Shaheryar Khan
Author URI: https://boir.org/
License: GPLv2 or later
Text Domain: boir-filling-system
*/
if (!session_start()) { session_start(); }
require( plugin_dir_path( __FILE__ ) . 'activate.php');
register_activation_hook( __FILE__, 'boir_manager_activate' );
require( plugin_dir_path( __FILE__ ) . 'deactivate.php');
register_deactivation_hook( __FILE__, 'boir_manager_deactivate' );

require( plugin_dir_path( __FILE__ ) . 'settings.php');
require( plugin_dir_path( __FILE__ ) . 'admin_nav.php');
require( plugin_dir_path( __FILE__ ) . 'admin_pages.php');
require( plugin_dir_path( __FILE__ ) . 'shortcodes.php');
require( plugin_dir_path( __FILE__ ) . 'ajax-functions.php');

function boir_manager_enqueue_assets() {
    wp_enqueue_style('bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css', array(), '1.11.3');
    wp_enqueue_style('boir-manager-style', plugin_dir_url(__FILE__) . 'css/boir-manager-style.css', array(), '1.0.0');
    wp_enqueue_script('boir-manager-script', plugin_dir_url(__FILE__) . 'js/boir-manager-script.js', array('jquery'), '1.0.0', true);
    wp_add_inline_script('boir-manager-script', 'var ajaxurl = "' . admin_url('admin-ajax.php') . '";');
}
add_action('wp_enqueue_scripts', 'boir_manager_enqueue_assets');


?>