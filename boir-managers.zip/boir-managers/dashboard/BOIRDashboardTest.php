<?php 
global $wpdb;
error_log($_SESSION['user_otp_logged_in']);

if (!isset($_SESSION['user_otp_logged_in'])) {
    if (!is_user_logged_in()) {
        error_log('2');
        if (!headers_sent()) {
            wp_redirect(home_url() . '/login');
            exit;
        } else {
            echo '<script>window.location.href = "' . esc_url(home_url() . '/login') . '";</script>';
            exit;
        }
    }elseif(!current_user_can('Customer')){
        error_log('3');
        if (!headers_sent()) {
            wp_redirect(home_url());
            exit;
        } else {
            echo '<script>window.location.href = "' . esc_url(home_url()) . '";</script>';
            exit;
        }
    }
}


?>
<div class="boir-manager-dashboard">
<?php 

    $clients_table = $wpdb->prefix . "boir_clients";
    $clients_fillings_table = $wpdb->prefix . "boir_clients_fillings";
    
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    if (isset($_SESSION['user_otp_logged_in'])) {
        error_log("*******");
        error_log($_SESSION['user_otp_logged_in']); 
        $user_id = $_SESSION['user_otp_logged_in'];
    }
    $client_info = $wpdb->get_row("SELECT * FROM $clients_table WHERE user_id = $user_id");
    error_log(print_r($client_info));
    
    if($client_info){
        $client_id = $client_info->id;
        $client_name = $client_info->client_name;
        $client_email = $client_info->client_email;
        $client_phone = $client_info->client_phone;

        $query = "SELECT c.id, c.filling_code, c.client_id, c.filling_status, c.client_fincen_id, c.filling_error_message, c.created_at, i.initial_legal_name
                  FROM $clients_fillings_table c
                  LEFT JOIN " . $wpdb->prefix . "boir_fillings_inital_data i ON c.id = i.filling_id
                  WHERE c.client_id = $client_id";

        if(isset($_GET['search']) && $_GET['search']!=''){
            $search = sanitize_text_field($_GET['search']);
            $query .= " AND i.initial_legal_name LIKE '%$search%'";
        }

        if(isset($_GET['filter']) && $_GET['filter']!=''){
            $filter = sanitize_text_field($_GET['filter']);
            $filter = $filter == 'incomplete' ? '0' : ($filter == 'in_progress' ? '1' : '2');
            $query .= " AND c.filling_status = $filter";
        }

        $query .= " ORDER BY c.id DESC";

        $fillings_info = $wpdb->get_results($query);
    ?>

<div class="boir-manager-dashboard">
    <div class="dashboard-header">
        <div class="header-content">
            <div class="header-title">My Companies</div>
            <div class="header-description">Find your companies fillings listed here.</div>
        </div>
        <div class="header-actions">
            <div class="search-box">
                <form action="" method="get">
                    <div class="field-with-button">
                        <input type="text" name="search" placeholder="Search by company name..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                        <button type="submit"><i class="bi bi-search"></i></button>
                    </div>
                </form>
            </div>
            <div class="filter-field">
                <select name="filter" id="boir-dashboard-filter">
                    <option value="">FILTER BY STATUS</option>
                    <option value="incomplete" <?php echo isset($_GET['filter']) && $_GET['filter'] == 'incomplete' ? 'selected' : ''; ?> >Incomplete</option>
                    <option value="in_progress" <?php echo isset($_GET['filter']) && $_GET['filter'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                    <option value="completed" <?php echo isset($_GET['filter']) && $_GET['filter'] == 'completed' ? 'selected' : ''; ?> >Completed</option>
                </select>
            </div>
            <div class="new-filling">
                <a href="<?php echo home_url(); ?>/file/" class="button button-primary">File New BOIR</a>
            </div>
        </div>
    </div>
    <div class="dashboard-content">
        <?php 
        if($fillings_info){
        ?>
        <div class="dashboard-items">
            <?php foreach($fillings_info as $filling_info){ 
                $filling_id = $filling_info->id;
                $filling_status = $filling_info->filling_status;
                $filling_code = $filling_info->filling_code;
                $filling_error_message = $filling_info->filling_error_message;

                $fillings_inital_data_table = $wpdb->prefix . "boir_fillings_inital_data";
                $fillings_inital_data = $wpdb->get_row("SELECT * FROM $fillings_inital_data_table WHERE filling_id = $filling_id");

                if($fillings_inital_data){
                    $company_name = $fillings_inital_data->initial_legal_name;
                    $trade_name = $fillings_inital_data->initial_alternate_name;
                    $tax_type = $fillings_inital_data->initial_tax_type;
                    $tax_number = $fillings_inital_data->initial_tax_number;
                }else{
                    $company_name = 'N / A';
                    $trade_name = 'N / A';
                    $tax_type = 'N / A';
                    $tax_number = 'N / A';
                }

                $fillings_jurisdiction_data_table = $wpdb->prefix . "boir_fillings_jurisdiction_data";
                $fillings_jurisdiction_data = $wpdb->get_row("SELECT * FROM $fillings_jurisdiction_data_table WHERE filling_id = $filling_id");

                if($fillings_jurisdiction_data){
                    $address_line_1 = $fillings_jurisdiction_data->juri_address_line_1;
                    $address_line_2 = $fillings_jurisdiction_data->juri_address_line_2;
                    $city = $fillings_jurisdiction_data->juri_city;
                    $state = $fillings_jurisdiction_data->juri_state;
                    $zip = $fillings_jurisdiction_data->juri_zip;

                    $business_address = $address_line_1 . ', ' . $city . ', ' . $state . ', ' . $zip;
                }else{
                    $business_address = 'N / A';
                }
                $statuses = [
                    0 => 'Incomplete',
                    1 => 'In Progress',
                    2 => 'Completed',
                ]
            ?>
            <div class="dashboard-item">
                <div class="item-status">
                    <div class="status-text" data-background="<?=$filling_status;?>"><?php echo $statuses[$filling_status]; ?></div>
                    <?php if($filling_status < 2){ ?>
                    <div class="status-message">
                        <i class="bi bi-info-circle-fill"></i>
                        <b>Attention: </b>
                        <span><?=$filling_error_message;?></span>
                    </div>
                    <?php } ?>
                </div>
                <div class="item-content">
                    <div class="item-details">
                        <div class="item-title"><?=$company_name;?></div>
                        <div class="item-data-container">
                            <div class="data-group">
                                <div class="item-data">
                                    <div class="item-data-label">Trade Name:</div>
                                    <div class="item-data-value"><?=$trade_name;?></div>
                                </div>
                                <div class="item-data">
                                    <div class="item-data-label"><?=$tax_type;?> Number:</div>
                                    <div class="item-data-value"><?=$tax_number;?></div>
                                </div>
                            </div>
                            <div class="data-group">
                                <div class="item-data">
                                    <div class="item-data-label">Business Address:</div>
                                    <div class="item-data-value"><?=$business_address; ?></div>
                                </div>
                                <div class="item-data">
                                    <div class="item-data-label">Application ID:</div>
                                    <div class="item-data-value"><?=$filling_code;?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item-actions">
                        <a href="<?php echo home_url(); ?>/file/?filling_id=<?php echo $filling_id; ?>" class="button button-secondary">Resume Filling</a>
                        <a href="<?php echo home_url(); ?>/dashboard/?view=filling&filling_id=<?php echo $filling_id; ?>" class="button button-primary">View</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
        <?php }else{ ?>
        <center>
            <div class="no-companies-found" style="padding-bottom: 50px;">
                <i class="bi bi-emoji-frown" style="font-size: 100px; color: #4a9cce"></i>
                <p>No Companies Found</p>
            </div>
        </center>
        <?php } ?>
    </div>
</div>
<?php 
    }else{
        echo '<center><div class="no-companies-found"><i class="bi bi-emoji-frown" style="font-size: 100px; color: #4a9cce"></i><p>Account Not Found - Contact Support</p></div></center>';
    }
?>
