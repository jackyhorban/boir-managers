<?php 

// admin_pages.php

function boir_manager_admin_menu_main() {
    global $wpdb;

    if (isset($_GET['action']) && isset($_GET['id'])) {
        $action = sanitize_text_field($_GET['action']);
        $id = intval($_GET['id']);
        $table_name = $wpdb->prefix . 'boir_clients_fillings';

        switch ($action) {
            case 'view':
                // Example: Fetch and display filling details
                $filling = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $id", ARRAY_A);
                if ($filling) {
                    if(isset($_GET['filling_status']) && $_GET['filling_status'] != ''){
                        $filling_status = $_GET['filling_status'];
//                         $filling_status_on_server = get_submit_status_by_id($id);
                        $filling_error_message = 'Unknown Error - Contact Support';

//                         if (isset($filling_status_on_server['errors'][0]['ErrorText'])) {
//                             $filling_error_message = $filling_status_on_server['errors'][0]['ErrorText'];
//                         }

                        $query = $wpdb->query("UPDATE $table_name SET filling_status = $filling_status, filling_error_message = '$filling_error_message' WHERE id = $id");
                        if($query){
                            if (!headers_sent()) {
                                wp_redirect(admin_url('admin.php?page=boir-manager-admin-menu&action=view&id=' . $id . '&success=filling_status'));
                                exit;
                            } else {
                                echo '<script type="text/javascript">';
                                echo 'window.location.href="' . admin_url('admin.php?page=boir-manager-admin-menu&action=view&id=' . $id . '&success=filling_status') . '";';
                                echo '</script>';
                                exit;
                            }
                            exit;
                        }else{
                            if (!headers_sent()) {
                                wp_redirect(admin_url('admin.php?page=boir-manager-admin-menu&action=view&id=' . $id . '&success=filling_status'));
                                exit;
                            } else {
                                echo '<script type="text/javascript">';
                                echo 'window.location.href="' . admin_url('admin.php?page=boir-manager-admin-menu&action=view&id=' . $id . '&success=filling_status') . '";';
                                echo '</script>';
                                exit;
                            }
                            exit;
                        }
                    }
                    echo '<div class="wrap"><h1>Filling Details</h1>';
                    if(isset($_GET['success']) && $_GET['success'] == 'filling_status'){
                        echo '  <div class="notice notice-success is-dismissible">
                                    <p><b>Filling Status Updated!</b></p>
                                </div>';
                    }
                        display_filling_details($id);
                    echo '</div>';
                } else {
                    wp_die('Filling not found.');
                }
                break;

            case 'delete':
                // Delete the record
                // $wpdb->delete($table_name, ['id' => $id]);
                if (!headers_sent()) {
                    wp_redirect(admin_url('admin.php?page=boir-manager-admin-menu'));
                    exit;
                } else {
                    echo '<script type="text/javascript">';
                    echo 'window.location.href="' . admin_url('admin.php?page=boir-manager-admin-menu') . '";';
                    echo '</script>';
                    exit;
                }
                exit;

            default:
                break;
        }
    }
    require plugin_dir_path(__FILE__) . '/admin_pages/dashboard.php';
}

function boir_manager_admin_menu_sub_clients_list() {
    global $wpdb;
    if (isset($_GET['action']) && isset($_GET['id'])) {
        $action = sanitize_text_field($_GET['action']);
        $id = intval($_GET['id']);
        $table_name = $wpdb->prefix . 'boir_clients';

        switch ($action) {
            case 'view':
                // Example: Fetch and display client details
                $clients = $wpdb->get_row("SELECT * FROM $table_name WHERE id = $id", ARRAY_A);
                if ($clients) {
                    
                    echo '<div class="wrap"><h1>Client Details</h1>';
                    if(isset($_GET['success']) && $_GET['success'] == 'client_status'){
                        echo '  <div class="notice notice-success is-dismissible">
                                    <p><b>Client Updated!</b></p>
                                </div>';
                    }
                        display_client_details($id);
                    echo '</div>';
                } else {
                    wp_die('Client not found.');
                }
                break;

            case 'delete':
                // Delete the record

                $clients = $wpdb->get_row("SELECT user_id FROM $table_name WHERE id = $id", ARRAY_A);
                if ($clients) {
                    $user_id = $clients['user_id'];
                    wp_delete_user($user_id);
                }
                if (!headers_sent()) {
                    wp_redirect(admin_url('admin.php?page=boir-manager-admin-menu-sub-clients-list'));
                    exit;
                } else {
                    echo '<script type="text/javascript">';
                    echo 'window.location.href="' . admin_url('admin.php?page=boir-manager-admin-menu-sub-clients-list') . '";';
                    echo '</script>';
                    exit;
                }
                exit;

            default:
                break;
        }
    }
    require plugin_dir_path(__FILE__) . '/admin_pages/clients_list.php';
}

function boir_manager_admin_menu_sub_forum1_list() {
    global $wpdb;
    if (isset($_GET['action']) && isset($_GET['id'])) {
        $action = sanitize_text_field($_GET['action']);
        $id = intval($_GET['id']);
    }
    
    require plugin_dir_path(__FILE__) . '/admin_pages/forum1_list.php';
}

function boir_manager_admin_menu_sub_forum2_list() {
    global $wpdb;
    if (isset($_GET['action']) && isset($_GET['id'])) {
        $action = sanitize_text_field($_GET['action']);
        $id = intval($_GET['id']);
    }
    
    require plugin_dir_path(__FILE__) . '/admin_pages/forum2_list.php';
}

function display_filling_details($filling_id){
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";
    $fillings_inital_data_table = $wpdb->prefix . "boir_fillings_inital_data";
    $fillings_jurisdiction_data_table = $wpdb->prefix . "boir_fillings_jurisdiction_data";
    $fillings_company_applicants_table = $wpdb->prefix . "boir_fillings_company_applicants";
    $fillings_beneficial_owners_table = $wpdb->prefix . "boir_fillings_beneficial_owners";
    $fillings_payments_table = $wpdb->prefix . "boir_fillings_payments";

    $filling_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_table WHERE id = %d",
        $filling_id
    ));

    $client_id = $filling_data->client_id;

    $filling_data = array(
        'filling_id' => $filling_data->id,
        'filling_code' => $filling_data->filling_code,
        'filling_fincen_id_request' => $filling_data->client_fincen_id,
        'filling_existing_reporting_company' => $filling_data->existing_reporting_company,
        'filling_authorization' => $filling_data->filling_authorization,
        'filling_status' => $filling_data->filling_status,
        'filling_created_at' => $filling_data->created_at,
    );

    $client_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $clients_table WHERE id = %d",
        $client_id
    ));

    $client_info = array(
        'client_id' => $client_data->id,
        'client_name' => $client_data->client_name,
        'client_email' => $client_data->client_email,
        'client_phone' => $client_data->client_phone,
        'client_conversion_from' => $client_data->client_conversion_from,
        'client_created_at' => $client_data->created_at,
    );

    $filling_inital_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_inital_data_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_inital_data = array(
        'legal_name' => $filling_inital_data->initial_legal_name,
        'alternate_name' => $filling_inital_data->initial_alternate_name,
        'tax_type' => $filling_inital_data->initial_tax_type,
        'tax_number' => $filling_inital_data->initial_tax_number
    );

    $filling_jurisdiction_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_jurisdiction_data_table WHERE filling_id = %d",
        $filling_id
    ));
    if(!$filling_jurisdiction_data){
        $filling_jurisdiction_data = array(
            'formation_country' => '',
            'formation_state' => '',
            'tribal' => '',
            'address_line_1' => '',
            'address_line_2' => '',
            'city' => '',
            'state' => '',
            'zip' => '',
            'created_at' => '',
        );
    }else{

        $filling_jurisdiction_data = array(
            'formation_country' => $filling_jurisdiction_data->juri_formation_country,
            'formation_state' => $filling_jurisdiction_data->juri_formation_state,
            'tribal' => $filling_jurisdiction_data->juri_tribal,
            'address_line_1' => $filling_jurisdiction_data->juri_address_line_1,
            'address_line_2' => $filling_jurisdiction_data->juri_address_line_2,
            'city' => $filling_jurisdiction_data->juri_city,
            'state' => $filling_jurisdiction_data->juri_state,
            'zip' => $filling_jurisdiction_data->juri_zip,
            'created_at' => $filling_jurisdiction_data->created_at,
        );

    }

    $filling_company_applicants = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $fillings_company_applicants_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_company_applicants_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $fillings_company_applicants_table WHERE filling_id = %d",
        $filling_id
    ));



    $filling_company_applicants_data = array();
    foreach ($filling_company_applicants as $company_applicant) {
        $filling_company_applicants_data[] = array(
            'last_name' => $company_applicant->applicant_last_name,
            'first_name' => $company_applicant->applicant_first_name,
            'middle_name' => $company_applicant->applicant_middle_name,
            'suffix' => $company_applicant->applicant_suffix,
            'dob' => $company_applicant->applicant_dob,
            'address_type' => $company_applicant->applicant_address_type,
            'address' => $company_applicant->applicant_address,
            'city' => $company_applicant->applicant_city,
            'state' => $company_applicant->applicant_state,
            'zip' => $company_applicant->applicant_zip,
            'id_image' => $company_applicant->applicant_id_image,
            'id_type' => $company_applicant->applicant_id_type,
            'id_number' => $company_applicant->applicant_id_number,
            'id_country' => $company_applicant->applicant_id_country,
            'id_state' => $company_applicant->applicant_id_state,
            'id_tribal_jurisdiction' => $company_applicant->applicant_id_tribal_jurisdiction,
            'created_at' => $company_applicant->created_at
        );
    }

    $filling_beneficial_owners = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $fillings_beneficial_owners_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_beneficial_owners_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $fillings_beneficial_owners_table WHERE filling_id = %d",
        $filling_id
    ));

    $filling_beneficial_owners_data = array();
    foreach ($filling_beneficial_owners as $beneficial_owner) {
        $filling_beneficial_owners_data[] = array(
            'owner_is_minor' => $beneficial_owner->owner_is_minor,
            'owner_exemption' => $beneficial_owner->owner_exemption,
            'last_name' => $beneficial_owner->owner_last_name,
            'first_name' => $beneficial_owner->owner_first_name,
            'middle_name' => $beneficial_owner->owner_middle_name,
            'suffix' => $beneficial_owner->owner_suffix,
            'dob' => $beneficial_owner->owner_dob,
            'address_type' => $beneficial_owner->owner_address_type,
            'address' => $beneficial_owner->owner_address,
            'city' => $beneficial_owner->owner_city,
            'country' => $beneficial_owner->owner_country,
            'state' => $beneficial_owner->owner_state,
            'zip' => $beneficial_owner->owner_zip,
            'id_image' => $beneficial_owner->owner_id_image,
            'id_type' => $beneficial_owner->owner_id_type,
            'id_number' => $beneficial_owner->owner_id_number,
            'id_country' => $beneficial_owner->owner_id_country,
            'id_state' => $beneficial_owner->owner_id_state,
            'id_tribal_jurisdiction' => $beneficial_owner->owner_id_tribal_jurisdiction,
            'created_at' => $beneficial_owner->created_at
        );
    }

    $filling_payments_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $fillings_payments_table WHERE filling_id = %d",
        $filling_id
    ));

    if (!$filling_payments_data) {
        $filling_payments_data = array(
            'payment_card_holder' => '',
            'payment_txn_id' => '',
            'payment_type' => '',
            'payment_amount' => '',
            'payment_card_number' => '',
            'payment_exp_date' => '',
            'payment_cvv' => '',
            'payment_card_country' => '',
            'payment_card_zip' => '',
            'payment_user_agent' => '',
            'payment_user_browser' => '',
            'payment_user_ip' => '',
            'payment_routing_number' => '',
            'payment_account_number' => '',
            'payment_authorization' => '',
            'payment_capture' => '',
            'payment_created_at' => ''
        );
    }else{

        $filling_payments_data = array(
            'payment_card_holder' => $filling_payments_data->payment_card_holder,
            'payment_txn_id' => $filling_payments_data->transaction_id,
            'payment_type' => $filling_payments_data->payment_type,
            'payment_amount' => $filling_payments_data->payment_amount,
            'payment_card_number' => $filling_payments_data->card_number,
            'payment_exp_date' => $filling_payments_data->exp_date,
            'payment_cvv' => $filling_payments_data->cvv,
            'payment_card_country' => $filling_payments_data->card_country,
            'payment_card_zip' => $filling_payments_data->card_zip,
            'payment_user_agent' => $filling_payments_data->user_agent,
            'payment_user_browser' => $filling_payments_data->user_browser,
            'payment_user_ip' => $filling_payments_data->user_ip,
            'payment_routing_number' => $filling_payments_data->routing_number,
            'payment_account_number' => $filling_payments_data->account_number,
            'payment_authorization' => $filling_payments_data->payment_authorization,
            'payment_created_at' => $filling_payments_data->created_at
        );

    }

    $filling_full_data = array(
        'client_info' => $client_info, 
        'filling_data' => $filling_data,
        'filling_initial_data' => $filling_inital_data,
        'filling_company_data' => $filling_jurisdiction_data,
        'filling_company_applicants_count' => $filling_company_applicants_count,
        'filling_company_applicants' => $filling_company_applicants_data,
        'filling_beneficial_owners_count' => $filling_beneficial_owners_count,
        'filling_beneficial_owners' => $filling_beneficial_owners_data,
        'filling_payment_data' => $filling_payments_data
    );

    $statuses = [
        0 => '<span style="color: red; border: 1px solid red; padding: 2px 5px;text-transform: uppercase">Incomplete</span>',
        1 => '<span style="color: #FFA500; border: 1px solid #FFA500; padding: 2px 5px;text-transform: uppercase">In Progress</span>',
        2 => '<span style="color: green; border: 1px solid green; padding: 2px 5px;text-transform: uppercase">Completed</span>',
    ];
    ?>
    <div class="filling_view_header" style="display: flex; justify-content: space-between;">
        <h2>Code: <?=$filling_full_data['filling_data']['filling_code'];?></h2>
        <a onclick="return confirm('Are you sure you want to change this?');" href="<?php echo admin_url('admin.php?page=boir-manager-admin-menu&action=view&filling_status=0&id=' . $filling_id); ?>"><button class="button button-secondary" style="background-color: #f52929; color:#fff; border-color: #f52929;" >Mark As Incomplete</button></a>
    </div>
    <div class="cards-container" style="display: flex; flex-wrap: wrap; flex-direction: row; gap: 10px;">

    <?php
    foreach ($filling_full_data as $key => $value) {
        $card_title = str_replace('_', ' ', $key);
        if($key == 'filling_beneficial_owners_count' || $key == 'filling_company_applicants_count'){ continue; }
        if($key == 'filling_company_applicants'){ $card_title = $card_title . ' ('. $filling_company_applicants_count .')' ; }
        if($key == 'filling_beneficial_owners'){ $card_title = $card_title . ' ('. $filling_beneficial_owners_count .')' ; }
    ?>
    <div class="card" style="flex-grow: 1; <?=$key == 'filling_payment_data' ? 'min-width: 100%;' : 'min-width: calc(50% - 5px);'?> margin-top: 0;">
        <h2 class="card-header" style="text-transform: capitalize;"><?=$card_title;?></h2>
        <div class="card-body">
    <?php
        foreach ($value as $key2 => $value2) {
            $card_title2 = str_replace('_', ' ', $key2);
            if($key2 == 'filling_fincen_id_request'){ $value2 == 0 ? $value2 = 'No' : $value2 = 'Yes'; }
            if($key2 == 'filling_status'){ $value2 = $statuses[$value2]; }
            if($key2 == 'client_conversion_from'){ $value2 = '<a href="'.$value2.'" target="_blank">'.$value2.'</a>'; }
            if($key2 == 'client_name'){ $value2 = '<a href="'.admin_url("admin.php?page=boir-manager-admin-menu-sub-clients-list&action=view&id={$client_id}").'" target="_blank">'.$value2.'</a>'; }

            $ignore_array = array('client_id', 'filling_id', 'created_at');
            if(in_array($key2, $ignore_array)){ continue; }
            if(is_array($value2)){
                echo '<div class="card" style="padding: 0">';
                $card_title2 = intval($card_title2+1);
                echo '<div style="font-weight: bold; padding:5px 10px; border-bottom: 1px solid #ccc; background-color: #d8d8d8;">Form '.$card_title2.' # </div>';
                foreach ($value2 as $key3 => $value3) {
                    $card_title3 = str_replace('_', ' ', $key3);
                    if($key3 == 'created_at'){ continue; }
                    if($key3 == 'id_image'){ $value3 = '<a href="'.$value3.'" target="_blank">View File</a>'; }
                    echo '  <div style="border-top: 1px solid #ccc; padding:5px 10px; display: flex;flex-grow: 1; justify-content: space-between;">
                                <strong style="text-transform: capitalize;">'.$card_title3.':</strong>
                                <span style="text-align: right">'.$value3.'</span>
                            </div>';
                }
                echo '</div>';
            }else{
                echo '  <div style="border-top: 1px solid #ccc; padding:5px 10px; display: flex;flex-grow: 1; justify-content: space-between;">
                            <strong style="text-transform: capitalize;">'.$card_title2.':</strong>
                            <span style="text-align: right">'.$value2.'</span>
                        </div>';
            }
            
        }
    ?>
        </div>
    </div>
    <?php
    }
    ?>
    </div>
    <?php
}

function display_client_details($client_id){
    global $wpdb;

    $clients_table = $wpdb->prefix . "boir_clients";
    $fillings_table = $wpdb->prefix . "boir_clients_fillings";

    
    $client_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $clients_table WHERE id = %d",
        $client_id
    ));

    
    $client_info = array(
        'client_id' => $client_data->id,
        'user_id' => $client_data->user_id,
        'client_name' => $client_data->client_name,
        'client_email' => $client_data->client_email,
        'client_phone' => $client_data->client_phone,
        'client_conversion_from' => $client_data->client_conversion_from,
        'client_created_at' => $client_data->created_at,
    );

    $fillings_rows = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $fillings_table WHERE client_id = %d",
        $client_data->id
    ));

    $fillings_rows_count = count($fillings_rows);

    $fillings_data = array();
    if ($fillings_rows) {
        foreach ($fillings_rows as $filling_row) {
            $fillings_data[] = array(
                'filling_id' => $filling_row->id,
                'filling_code' => $filling_row->filling_code,
                'filling_fincen_id_request' => $filling_row->client_fincen_id,
                'filling_existing_reporting_company' => $filling_row->existing_reporting_company,
                'filling_authorization' => $filling_row->filling_authorization,
                'filling_status' => $filling_row->filling_status,
                'filling_created_at' => $filling_row->created_at,
            );
        }
    }

    $client_full_data = array(
        'client_info' => $client_info,
        'fillings_rows_count' => $fillings_rows_count,
        'fillings_data' => $fillings_data
    );
    $statuses = [
        0 => '<span style="color: red; border: 1px solid red; padding: 2px 5px;text-transform: uppercase">Incomplete</span>',
        1 => '<span style="color: #FFA500; border: 1px solid #FFA500; padding: 2px 5px;text-transform: uppercase">In Progress</span>',
        2 => '<span style="color: green; border: 1px solid green; padding: 2px 5px;text-transform: uppercase">Completed</span>',
    ];

    ?>
    <div class="filling_view_header" style="display: flex; justify-content: space-between;">
        <b>Total Fillings: <?=$fillings_rows_count?></b>
        <a onclick="return confirm('Are you sure you want to delete this?');" href="<?php echo admin_url('admin.php?page=boir-manager-admin-menu-sub-clients-list&action=delete&id=' . $client_id); ?>"><button class="button button-secondary" style="background-color: #f52929; color:#fff; border-color: #f52929;" >Delete Client and Data</button></a>
    </div>
    <div class="cards-container" style="display: flex; flex-wrap: wrap; flex-direction: row; gap: 10px;">

    <?php
    $filling_id = '';
    foreach ($client_full_data as $key => $value) {
        $card_title = str_replace('_', ' ', $key);
        if($key == 'fillings_rows_count'){ continue; }
    ?>
    <div class="card" style="flex-grow: 1; min-width: 100%; margin-top: 0;">
        <h2 class="card-header" style="text-transform: capitalize;"><?=$card_title;?></h2>
        <div class="card-body" style="display: flex; flex-wrap: wrap; flex-direction: row; gap: 10px;">
    <?php
        foreach ($value as $key2 => $value2) {
            $card_title2 = str_replace('_', ' ', $key2);

            $ignore_array2 = array('client_id', 'filling_id');
            if(in_array($key2, $ignore_array2)){ continue; }
            if($key2 == 'client_conversion_from'){ $value2 = '<a href="'.$value2.'" target="_blank">'.$value2.'</a>'; }
            if(is_array($value2)){
                echo '<div class="card" style="padding: 0">';
                $card_title2 = intval($card_title2+1);
                echo '<div style="font-weight: bold; padding:5px 10px; border-bottom: 1px solid #ccc; background-color: #d8d8d8;">Filling '.$card_title2.' # </div>';
                foreach ($value2 as $key3 => $value3) {
                    $card_title3 = str_replace('_', ' ', $key3);
                    $ignore_array3 = array('filling_authorization', 'filling_existing_reporting_company');
                    if(in_array($key3, $ignore_array3)){ continue; }
                    if($key3 == 'filling_id'){ $filling_id = $value3;  continue; }
                    if($key3 == 'filling_fincen_id_request'){ $value3 == 0 ? $value3 = 'No' : $value3 = 'Yes'; }
                    if($key3 == 'filling_status'){ $value3 = $statuses[$value3]; }
                    if($key3 == 'filling_code'){ $value3 = '<a href="'.admin_url('admin.php?page=boir-manager-admin-menu&action=view&id='.$filling_id).'" target="_blank">'.$value3.'</a>'; }
                    echo '  <div style="border-top: 1px solid #ccc; padding:5px 10px; display: flex;flex-grow: 1; justify-content: space-between;">
                                <strong style="text-transform: capitalize;">'.$card_title3.':</strong>
                                <span style="text-align: right">'.$value3.'</span>
                            </div>';
                }
                echo '</div>';
            }else{
                echo '  <div style="border-right: 1px solid #ccc;border-left: 1px solid #ccc; background-color: #d8d8d8; padding:5px 10px; display: flex;flex-grow: 1; justify-content: space-between;">
                            <strong style="text-transform: capitalize;">'.$card_title2.':</strong>
                            <span style="text-align: right">'.$value2.'</span>
                        </div>';
            }
            
        }
    ?>
        </div>
    </div>
    <?php
    }
    ?>
    </div>
    <?php
}